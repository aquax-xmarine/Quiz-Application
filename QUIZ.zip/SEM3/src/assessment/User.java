package assessment;

/**
 * Represents a user in the system, with a specified level.
 * This class is used to manage the user's level, which can be used for various purposes such as access control or categorization.
 */
public class User {

    private String level;

    /**
     * Constructor to create a User with a specified level.
     * 
     * @param level The level of the user (e.g., "Beginner", "Intermediate", "Advanced").
     */
    public User(String level) {
        this.level = level;
    }

    /**
     * Returns the level of the user.
     * 
     * @return The level of the user as a String.
     */
    public String getLevel() {
        return level;
    }
}
