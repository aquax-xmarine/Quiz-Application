package assessment;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.LinkedList;

/**
 * The {@code Register} class represents a registration form for competitors in a competition.
 * It provides fields for the competitor's personal information and allows the user to submit
 * the registration to a database. The form also has buttons for submitting the registration,
 * navigating back to the homepage, and exiting the application.
 */
public class Register extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    public JTextField txtFirstName;
    public JTextField txtLastName;
    public JTextField txtID;
    public JTextField txtAge;
    public JComboBox<String> comboLevel;
    public CompetitionDB dbManager;
    public JButton btnSubmit;
    
    // List to store competitors
    private LinkedList<Competitor> competitors = new LinkedList<>();

    /**
     * Launches the registration form application.
     *
     * @param args Command-line arguments (not used in this application).
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Register frame = new Register();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Constructs the registration form frame and initializes the components.
     * 
     */
    public Register() {
        dbManager = new CompetitionDB();
//    	dbManager.createTable();
    	
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 465, 400);
        contentPane = new JPanel();
        contentPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Initialize the UI components
        JLabel lblTitle = new JLabel("Register");
        lblTitle.setFont(new Font("Viner Hand ITC", Font.PLAIN, 30));
        lblTitle.setBounds(168, 10, 130, 49);
        contentPane.add(lblTitle);

        JLabel lblID = new JLabel("ID:");
        lblID.setBounds(109, 68, 61, 13);
        contentPane.add(lblID);

        txtID = new JTextField();
        txtID.setBounds(180, 65, 176, 19);
        contentPane.add(txtID);
        txtID.setColumns(10);

        JLabel lblFirstName = new JLabel("First Name:");
        lblFirstName.setBounds(109, 100, 80, 13);
        contentPane.add(lblFirstName);

        txtFirstName = new JTextField();
        txtFirstName.setBounds(180, 97, 176, 19);
        contentPane.add(txtFirstName);
        txtFirstName.setColumns(10);

        JLabel lblLastName = new JLabel("Last Name:");
        lblLastName.setBounds(109, 133, 80, 13);
        contentPane.add(lblLastName);

        txtLastName = new JTextField();
        txtLastName.setBounds(180, 130, 176, 19);
        contentPane.add(txtLastName);
        txtLastName.setColumns(10);

        JLabel lblAge = new JLabel("Age:");
        lblAge.setBounds(109, 165, 80, 13);
        contentPane.add(lblAge);

        txtAge = new JTextField();
        txtAge.setBounds(180, 162, 176, 19);
        contentPane.add(txtAge);
        txtAge.setColumns(10);

        JLabel lblLevel = new JLabel("Level:");
        lblLevel.setBounds(109, 199, 80, 13);
        contentPane.add(lblLevel);

        comboLevel = new JComboBox<>(new String[]{"Beginner", "Intermediate", "Advanced"});
        comboLevel.setBounds(180, 193, 176, 25);
        contentPane.add(comboLevel);

        btnSubmit = new JButton("Submit");
        btnSubmit.setBounds(180, 241, 120, 25);
        contentPane.add(btnSubmit);
        
        JButton btnBack = new JButton("Back");
        btnBack.setBounds(351, 287, 85, 21);
        contentPane.add(btnBack);

        JButton btnExit = new JButton("Exit");
        btnExit.setBounds(351, 312, 85, 21);
        contentPane.add(btnExit);

        // Action listener for the "Submit" button
        btnSubmit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Fetch input data
                try {
                    int id = Integer.parseInt(txtID.getText());
                    String firstName = txtFirstName.getText();
                    String lastName = txtLastName.getText();
                    int age = Integer.parseInt(txtAge.getText());
                    String level = (String) comboLevel.getSelectedItem();

                    // Validate inputs
                    if (firstName.isEmpty() || lastName.isEmpty() || age <= 0) {
                        JOptionPane.showMessageDialog(contentPane, "Please fill all fields correctly.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    
                    // Check if the ID already exists in the database
                    boolean isExistingCompetitor = dbManager.checkCompetitorExists(id);

                    if (isExistingCompetitor) {
                        // Show an error message if the competitor ID already exists
                        JOptionPane.showMessageDialog(contentPane, "Competitor with this ID already exists.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    
                    // Create Name and Competitor objects
                    Name name = new Name(firstName, lastName);
                    Competitor competitor = new Competitor(id, name, level, age, new int[]{});

                    // Add to the competitors list
                    competitors.add(competitor);
                    
                    // Insert into the database
                    dbManager.insertCompetitor(id, firstName, lastName, age, level);

                    // Show success message
                    JOptionPane.showMessageDialog(contentPane, "Competitor registered successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

                    // Clear input fields
                    clearFields();
                    
                    // Open the QuizGUI window
                    QuizGUI quizGUI = new QuizGUI(level, id);  
                    quizGUI.setVisible(true);
                    dispose();  

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(contentPane, "Invalid number format for ID or Age.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Action listener for the "Back" button
        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Homepage homepage = new Homepage();
                homepage.setVisible(true);
                dispose();
            }
        });

        // Action listener for the "Exit" button
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }

    /**
     * Clears the input fields in the registration form.
     */
    private void clearFields() {
        txtID.setText("");
        txtFirstName.setText("");
        txtLastName.setText("");
        txtAge.setText("");
        comboLevel.setSelectedIndex(0);
    }
}
