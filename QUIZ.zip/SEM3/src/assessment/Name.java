package assessment;

/**
 * The {@code Name} class represents an individual's name.
 * It provides methods to retrieve the full name, initials, 
 * first name, and last name.
 * 
 * @author Nikisha Shrestha 
 * @version 1.0
 */
class Name {
    private String firstName;
    private String lastName;

    /**
     * Constructor to initialize the Name object with first and last names.
     *
     * @param firstName The first name of the individual.
     * @param lastName The last name of the individual.
     */
    public Name(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    /**
     * Returns the initials of the individual, using the first letter of the first and last name.
     * 
     * @return The initials in uppercase.
     */
    public String getInitials() {
        return ("" + firstName.charAt(0) + lastName.charAt(0)).toUpperCase();
    }

    /**
     * Returns the full name of the individual.
     * 
     * @return The full name as "firstName lastName".
     */
    public String getFullName() {
        return firstName + " " + lastName;
    }

    /**
     * Returns the first name of the individual.
     * 
     * @return The first name.
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Returns the last name of the individual.
     * 
     * @return The last name.
     */
    public String getLastName() {
        return lastName;
    }
}
