package assessment;
import java.sql.*;
import java.util.List;
import java.util.LinkedList;

/**
 * The {@code CompetitionDB} class provides methods for interacting with a MySQL database
 * for managing competitor information and quiz questions.  It handles database connection,
 * table creation, data insertion, retrieval, and updates.
 */
public class CompetitionDB {
	private static final String DB_URL = "jdbc:mysql://localhost/competitiondb";
	private static final String USER = "root";
	private static final String PASSWORD = "";
	
	private Connection conn;
	
	/**
     * Constructs a {@code CompetitionDB} object and establishes a connection to the database.
     */
	public CompetitionDB() {
        try {
            conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);
            System.out.println("Database connected successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to connect to database.");
        }
    }
	
	/**
     * Creates the 'competitiondb' database.
     */
	public void createDatabase() {
		String query = "create database competitiondb";
				
		try (Statement stmt = conn.createStatement()){
			stmt.executeUpdate(query);
			System.out.println("Database 'competitiondb' created successfully.");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
     * Creates the 'Competitors' table.
     */
	public void createTable() {
	    String query = "CREATE TABLE Competitors ("
	            + "ID INT PRIMARY KEY, "
	            + "First_Name VARCHAR(50), "
	            + "Last_Name VARCHAR(50), "
	            + "Age INT, "
	            + "Level VARCHAR(50), "
	            + "Score1 INT, "
	            + "Score2 INT, "
	            + "Score3 INT, "
	            + "Score4 INT, "
	            + "Score5 INT)";

	    try (Statement stmt = conn.createStatement()) {
	        stmt.executeUpdate(query);
	        System.out.println("Table 'Competitors' created successfully.");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	
	/**
     * Inserts a new competitor's details into the 'Competitors' table.  Scores are initialized to 0.
     *
     * @param id        The competitor's ID.
     * @param firstName The competitor's first name.
     * @param lastName  The competitor's last name.
     * @param age       The competitor's age.
     * @param level     The competitor's level.
     */
	public void insertCompetitor(int id, String firstName, String lastName, int age, String level) {
        String query = "INSERT INTO Competitors (ID, First_Name, Last_Name, Age, Level, Score1, Score2, Score3, Score4, Score5) "
                     + "VALUES (?, ?, ?, ?, ?, 0, 0, 0, 0, 0)"; // Set scores to 0 initially
        
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            // Set values for the PreparedStatement
            stmt.setInt(1, id); // ID
            stmt.setString(2, firstName); // First Name
            stmt.setString(3, lastName); // Last Name
            stmt.setInt(4, age); // Age
            stmt.setString(5, level); // Level

            // Execute the insert statement
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                System.out.println("Competitor added successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while inserting competitor details.");
        }
    }
	
	/**
     * Updates a competitor's score.  This method finds the first available (empty) score column
     * and updates it with the provided score.
     *
     * @param id    The competitor's ID.
     * @param score The score to update.
     */
	public void updateScore(int id, int score) {
	    // Check which score column is available (Score1, Score2, Score3, ...)
	    String checkQuery = "SELECT Score1, Score2, Score3, Score4, Score5 FROM Competitors WHERE ID = ?";
	    
	    try (PreparedStatement stmtCheck = conn.prepareStatement(checkQuery)) {
	        stmtCheck.setInt(1, id);
	        ResultSet rs = stmtCheck.executeQuery();

	        if (rs.next()) {
	            // Loop to check for the first available (empty) Score column
	            for (int i = 1; i <= 5; i++) {
	                String scoreColumn = "Score" + i;
	                int existingScore = rs.getInt(scoreColumn);
	                
	                if (existingScore == 0) { // Find first available empty score column
	                    String updateQuery = "UPDATE Competitors SET " + scoreColumn + " = ? WHERE ID = ?";
	                    try (PreparedStatement stmtUpdate = conn.prepareStatement(updateQuery)) {
	                        stmtUpdate.setInt(1, score);
	                        stmtUpdate.setInt(2, id);
	                        int rowsAffected = stmtUpdate.executeUpdate();
	                        
	                        if (rowsAffected > 0) {
	                            System.out.println("Score updated successfully in " + scoreColumn);
	                        }
	                    } catch (SQLException e) {
	                        e.printStackTrace();
	                        System.out.println("Error while updating the score.");
	                    }
	                    break; // Exit loop after updating first available score column
	                }
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        System.out.println("Error while fetching and updating the score.");
	    }
	}
	
	
	
	
	/**
     * Checks if a competitor with the given ID already exists in the 'Competitors' table.
     *
     * @param id The competitor's ID to check.
     * @return {@code true} if a competitor with the ID exists, {@code false} otherwise.
     */
	public boolean checkCompetitorExists(int id) {
	    // SQL query to check if the ID already exists
	    String query = "SELECT COUNT(*) FROM competitors WHERE id = ?";
	    
	    try (PreparedStatement pstmt = conn.prepareStatement(query)) {
	        pstmt.setInt(1, id);
	        ResultSet rs = pstmt.executeQuery();

	        if (rs.next() && rs.getInt(1) > 0) {
	            // ID already exists in the database
	            return true;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false; // ID doesn't exist
	}

	
	/**
     * Creates the 'quiz' table.
     */
	public void createQuizTable() {
		String query = "create table quiz (QuestionID INT PRIMARY KEY AUTO_INCREMENT,"
				+ "    QuestionText VARCHAR(500),"
				+ "    OptionA VARCHAR(255),"
				+ "    OptionB VARCHAR(255),"
				+ "    OptionC VARCHAR(255),"
				+ "    OptionD VARCHAR(255),"
				+ "    CorrectAnswer CHAR(1),"
				+ "    Level varchar(50))"; 
		
		try (Statement stmt = conn.createStatement()){
			stmt.executeUpdate(query);
			System.out.println("Table 'quiz' created successfully.");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	/**
     * Adds a new question to the 'quiz' table.
     *
     * @param question      The question text.
     * @param optionA       Option A.
     * @param optionB       Option B.
     * @param optionC       Option C.
     * @param optionD       Option D.
     * @param correctAnswer The correct answer (A, B, C, or D).
     * @param level         The question level.
     * @return {@code true} if the question was added successfully, {@code false} otherwise.
     */
	public boolean addQuestion(String question, String optionA, String optionB, String optionC, String optionD, String correctAnswer, String level) {
        String query = "INSERT INTO quiz (QuestionText, OptionA, OptionB, OptionC, OptionD, CorrectAnswer, Level) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, question);
            pstmt.setString(2, optionA);
            pstmt.setString(3, optionB);
            pstmt.setString(4, optionC);
            pstmt.setString(5, optionD);
            pstmt.setString(6, correctAnswer);
            pstmt.setString(7, level);

            pstmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
	
	/**
	 * Updates the details of a question in the quiz database.
	 *
	 * @param questionID    The ID of the question to update.
	 * @param question      The new question text.
	 * @param optionA       The new option A.
	 * @param optionB       The new option B.
	 * @param optionC       The new option C.
	 * @param optionD       The new option D.
	 * @param correctAnswer The new correct answer.
	 * @param level         The new level of the question.
	 * @return true if the question was updated successfully, false otherwise.
	 */
	public boolean updateQuestion(int questionID, String question, String optionA, String optionB, String optionC, String optionD, String correctAnswer, String level) {
	    String query = "UPDATE quiz SET QuestionText = ?, OptionA = ?, OptionB = ?, OptionC = ?, OptionD = ?, CorrectAnswer = ?, Level = ? WHERE QuestionID = ?";
	    try (PreparedStatement pstmt = conn.prepareStatement(query)) {

	        pstmt.setString(1, question);
	        pstmt.setString(2, optionA);
	        pstmt.setString(3, optionB);
	        pstmt.setString(4, optionC);
	        pstmt.setString(5, optionD);
	        pstmt.setString(6, correctAnswer);
	        pstmt.setString(7, level);
	        pstmt.setInt(8, questionID);

	        int rowsUpdated = pstmt.executeUpdate();
	        return rowsUpdated > 0; // Returns true if a row was updated
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	        return false;
	    }
	}

	/**
	 * Deletes a question from the quiz database based on the question ID.
	 *
	 * @param questionId The ID of the question to delete.
	 * @return true if the question was deleted successfully, false otherwise.
	 */
	public boolean deleteQuestionById(String questionId) {
	    String query = "DELETE FROM quiz WHERE QuestionID = ?";
	    try (PreparedStatement pstmt = conn.prepareStatement(query)) {

	        pstmt.setInt(1, Integer.parseInt(questionId)); // Convert to int
	        int rowsAffected = pstmt.executeUpdate();
	        return rowsAffected > 0; // If one or more rows were affected, deletion was successful
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	        return false;
	    }
	}

	/**
	 * Fetches a list of questions based on the specified level.
	 *
	 * @param Level The level of the questions to fetch.
	 * @return A list of questions that belong to the specified level.
	 */
	public List<QuestionText> fetchQuestions(String Level) {
	    List<QuestionText> questionList = new LinkedList<>();
	    String query = "SELECT * FROM quiz WHERE Level = ?";

	    try (PreparedStatement pstmt = conn.prepareStatement(query)) {
	        pstmt.setString(1, Level);
	        ResultSet rs = pstmt.executeQuery();

	        while (rs.next()) {
	            questionList.add(new QuestionText(
	                    rs.getString("QuestionText"),  // Corrected column name
	                    rs.getString("OptionA"),
	                    rs.getString("OptionB"),
	                    rs.getString("OptionC"),
	                    rs.getString("OptionD"),
	                    rs.getString("CorrectAnswer")  // Corrected column name
	            ));
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return questionList;
	}
	
	/**
	 * Retrieves the level of a user based on their competitor ID.
	 *
	 * @param competitorID The competitor ID of the user.
	 * @return A User object representing the user, or null if the user is not found.
	 */
	public User getUserByID(int competitorID) {
        User user = null;
        String query = "SELECT Level FROM competitors WHERE ID = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)){
            pstmt.setInt(1, competitorID);

            ResultSet resultSet = pstmt.executeQuery();
            if (resultSet.next()) {
                String level = resultSet.getString("level");
                user = new User(level); // Create and return a User object
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return user; // Return the user object (or null if not found)
    }
	

	
	/**
	 * Checks if all score columns for a user are filled (non-zero).
	 *
	 * @param competitorID The competitor ID of the user.
	 * @return true if all score columns are filled, false otherwise.
	 */
    public boolean checkIfScoresFilled(int competitorID) {
        boolean allFilled = true;
        ResultSet rs = null;
        String query = "SELECT Score1, Score2, Score3, Score4 FROM competitors WHERE ID = ?";
        
        try (PreparedStatement pstmt = conn.prepareStatement(query)){
            pstmt.setInt(1, competitorID);

            // Execute the query
            rs = pstmt.executeQuery();

            // Check if a result was returned (user exists)
            if (rs.next()) {
                // Check if all score columns are non-null or non-zero (adjust based on your criteria)
                if (rs.getInt("score1") == 0 || rs.getInt("score2") == 0 || rs.getInt("score3") == 0 || rs.getInt("score4") == 0) {
                    allFilled = false;
                }
            } else {
                // If no data was found for the user, assume scores are not filled
                allFilled = false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            allFilled = false; // If there is an exception, assume the scores are not filled
        } 
        return allFilled;
    }
	
    /**
     * Fetches the details and scores of a competitor based on their competitor ID.
     *
     * @param competitorID The competitor ID.
     * @return A Competitor object containing the competitor's details and scores.
     * @throws SQLException If there is an error during database interaction.
     */
    public Competitor getCompetitorDetailsAndScores(int competitorID) throws SQLException {
        Competitor competitor = null;
        String query = "SELECT First_Name, Last_Name, Level, Age, Score1, Score2, Score3, Score4, Score5 FROM competitors WHERE ID = ?";
        
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {

        	pstmt.setInt(1, competitorID);
            try (ResultSet resultSet = pstmt.executeQuery()) { // Only one ResultSet
                if (resultSet.next()) {
                    String firstName = resultSet.getString("First_Name");  // Corrected column names
                    String lastName = resultSet.getString("Last_Name");    // Corrected column names
                    String level = resultSet.getString("Level");        // Corrected column names
                    int age = resultSet.getInt("Age");                // Corrected column names
                    Name name = new Name(firstName, lastName);

                    int[] scores = new int[5];
                    scores[0] = resultSet.getInt("Score1");        // Corrected column names
                    scores[1] = resultSet.getInt("Score2");        // Corrected column names
                    scores[2] = resultSet.getInt("Score3");        // Corrected column names
                    scores[3] = resultSet.getInt("Score4");        // Corrected column names
                    scores[4] = resultSet.getInt("Score5");        // Corrected column names

                    competitor = new Competitor(competitorID, name, level, age, scores);
                }
            }
        }
        return competitor;
    }


    /**
     * Fetches the leaderboard of competitors, sorted by their overall score.
     *
     * @param level The level to filter competitors by. If "All", fetches all competitors.
     * @return A sorted list of Competitor objects based on their overall scores.
     */
    public List<Competitor> getLeaderboard(String level) {
        List<Competitor> leaderboard = new LinkedList<>();
        String query;

        if (level.equals("All")) {
            query = "SELECT * FROM Competitors";  // Get all competitors
        } else {
            query = "SELECT * FROM Competitors WHERE Level = ?";  // Get only selected level
        }

        try (PreparedStatement pstmt = conn.prepareStatement(query))   {

            if (!level.equals("All")) {
                pstmt.setString(1, level); // Filter by level
            }

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("ID");
                String firstName = rs.getString("First_Name");
                String lastName = rs.getString("Last_Name");
                int age = rs.getInt("Age");
                String lvl = rs.getString("Level");
                
                // Create Name object
                Name competitorName = new Name(firstName, lastName);
                
                // Store scores in an array
                int[] scores = {
                    rs.getInt("Score1"),
                    rs.getInt("Score2"),
                    rs.getInt("Score3"),
                    rs.getInt("Score4"),
                    rs.getInt("Score5")
                };

                Competitor competitor = new Competitor(id, competitorName, lvl, age, scores);
                leaderboard.add(competitor);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Sort by overall score in descending order
        leaderboard.sort((c1, c2) -> Double.compare(c2.getOverallScore(), c1.getOverallScore()));

        return leaderboard;
    }
    
    /**
     * Returns the total number of competitors stored in the database.
     * 
     * @return The total number of competitors.
     */
    public int getTotalPlayers() {
        int totalPlayers = 0;
        String query = "SELECT COUNT(*) AS total FROM competitors"; // Replace 'competitors' with your actual table name

        try (PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery(query)) {

            if (rs.next()) {
                totalPlayers = rs.getInt("total"); // Get the total count from the result set
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return totalPlayers;
    }
    
    /**
    * Fetches all competitors from the database or competitors filtered by level.
    * 
    * @param level The level to filter competitors by (use "All" to fetch all competitors).
    * @return A list of competitors.
    */
    public List<Competitor> getCompetitors(String level) {
        List<Competitor> competitors = new LinkedList<>();
        String query;

        if (level.equals("All")) {
            query = "SELECT * FROM Competitors";  // Get all competitors
        } else {
            query = "SELECT * FROM Competitors WHERE Level = ?";  // Filter by level
        }

        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            if (!level.equals("All")) {
                pstmt.setString(1, level);
            }

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("ID");
                String firstName = rs.getString("First_Name");
                String lastName = rs.getString("Last_Name");
                int age = rs.getInt("Age");
                String lvl = rs.getString("Level");

                // Store scores
                int[] scores = {
                    rs.getInt("Score1"),
                    rs.getInt("Score2"),
                    rs.getInt("Score3"),
                    rs.getInt("Score4"),
                    rs.getInt("Score5")
                };

                // Create Name and Competitor objects
                Name competitorName = new Name(firstName, lastName);
                Competitor competitor = new Competitor(id, competitorName, lvl, age, scores);
                competitors.add(competitor);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return competitors;
    }
    
    /**
     * Creates a 'reports' table in the database.
     * The table contains columns for competitor information, including their highest score.
     */
    public void createReportTable() {
	    String query = "CREATE TABLE reports ("
	            + "ID INT PRIMARY KEY, "
	            + "First_Name VARCHAR(50), "
	            + "Last_Name VARCHAR(50), "
	            + "Age INT, "
	            + "Level VARCHAR(50), "
	            + "Score1 INT, "
	            + "Score2 INT, "
	            + "Score3 INT, "
	            + "Score4 INT, "
	            + "Score5 INT,"
	            + "Highest_Score INT)";

	    try (Statement stmt = conn.createStatement()) {
	        stmt.executeUpdate(query);
	        System.out.println("Table 'Reports' created successfully.");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
    
    /**
     * Populates the 'reports' table by extracting data from the 'competitors' table 
     * and calculating the highest score for each competitor.
     */
    public void populateReportTable() {
        String query = "SELECT * FROM competitors";  // Get all data from competitors table
        String insertQuery = "INSERT INTO reports (ID, First_Name, Last_Name, Age, Level, Score1, Score2, Score3, Score4, Score5, Highest_Score) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        String checkQuery = "SELECT ID FROM reports WHERE ID = ?";  // Check if the record already exists

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query);
             PreparedStatement pstmt = conn.prepareStatement(insertQuery);
             PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {

            while (rs.next()) {
                int id = rs.getInt("ID");
                String firstName = rs.getString("First_Name");
                String lastName = rs.getString("Last_Name");
                int age = rs.getInt("Age");
                String level = rs.getString("Level");
                int score1 = rs.getInt("Score1");
                int score2 = rs.getInt("Score2");
                int score3 = rs.getInt("Score3");
                int score4 = rs.getInt("Score4");
                int score5 = rs.getInt("Score5");

                // Find the highest score
                int highestScore = Math.max(Math.max(score1, score2), Math.max(Math.max(score3, score4), score5));

                // Check if the record already exists in the reports table
                checkStmt.setInt(1, id);
                ResultSet checkRs = checkStmt.executeQuery();

                if (!checkRs.next()) {  // If the ID doesn't exist, insert the data
                    pstmt.setInt(1, id);
                    pstmt.setString(2, firstName);
                    pstmt.setString(3, lastName);
                    pstmt.setInt(4, age);
                    pstmt.setString(5, level);
                    pstmt.setInt(6, score1);
                    pstmt.setInt(7, score2);
                    pstmt.setInt(8, score3);
                    pstmt.setInt(9, score4);
                    pstmt.setInt(10, score5);
                    pstmt.setInt(11, highestScore);

                    pstmt.executeUpdate();
                } else {
                    System.out.println("ID " + id + " already exists in reports table.");
                }

                checkRs.close();  // Always close the ResultSet
            }

            System.out.println("Reports table populated with highest scores.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Fetches all reports from the 'reports' table filtered by level.
     * 
     * @param level The level to filter reports by (use "All" to fetch all reports).
     * @return A list of competitor reports.
     */
    public List<CompetitorReport> getReports(String level) {
        List<CompetitorReport> reports = new LinkedList<>();
        String query = "SELECT * FROM reports";

        // Apply level filter if selected
        if (!level.equals("All")) {
            query += " WHERE Level = ?";
        }

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            if (!level.equals("All")) {
                stmt.setString(1, level);
            }
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                String firstName = rs.getString("First_Name");
                String lastName = rs.getString("Last_Name");
                int age = rs.getInt("Age");
                String lvl = rs.getString("Level");

                // Create Name object
                Name competitorName = new Name(firstName, lastName);

                // Store scores in an array
                int[] scores = {
                    rs.getInt("Score1"),
                    rs.getInt("Score2"),
                    rs.getInt("Score3"),
                    rs.getInt("Score4"),
                    rs.getInt("Score5"),
                };

                int highest_score = rs.getInt("Highest_Score");

                Competitor competitor = new Competitor(id, competitorName, lvl, age, scores);
                reports.add(new CompetitorReport(competitor, highest_score));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return reports;
    }


    
    
    
    /**
     * Closes the database connection.
     */
	public void closeConnection() {
        try {
            if (conn != null) {
                conn.close();
                System.out.println("Database connection closed.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	
	/**
     * Main method for testing the functionality of the CompetitionDB class.
     * 
     * @param args Command-line arguments (not used).
     */
	public static void main(String[] args) {
		CompetitionDB reportTable = new CompetitionDB();
//        reportTable.createReportTable();
		reportTable.populateReportTable();
        
        
    }

	
}
	




































