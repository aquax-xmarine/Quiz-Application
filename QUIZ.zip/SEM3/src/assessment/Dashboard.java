package assessment;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * The Dashboard class represents the main screen for the user interface of the system.
 * It provides access to two main sections of the application: the Admin Panel and the Players Panel.
 * The user can also exit the application from this screen.
 * 
 * <p>The class creates a JFrame with the following components:</p>
 * <ul>
 *   <li>A JLabel to display the title "Dashboard".</li>
 *   <li>Buttons to navigate to the Admin Panel and Players Panel, and to exit the application.</li>
 * </ul>
 */
public class Dashboard extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    /**
     * Launches the application.
     * This method is called from the main thread to initialize and display the Dashboard window.
     *
     * @param args Command-line arguments passed to the application (not used in this method).
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Dashboard frame = new Dashboard();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Creates the frame for the Dashboard.
     * This constructor initializes and configures the main window, setting up its layout,
     * labels, buttons, and action listeners.
     */
    public Dashboard() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 462, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel frame = new JLabel("Dashboard");
        frame.setFont(new Font("Viner Hand ITC", Font.PLAIN, 30));
        frame.setHorizontalAlignment(SwingConstants.CENTER);
        frame.setBounds(134, 56, 198, 45);
        contentPane.add(frame);

        JButton btnAdmin = new JButton("Admin Panel");
        btnAdmin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Opens the Admin Credentials panel when the button is clicked
                AdminCredentials adminCredentials = new AdminCredentials();
                adminCredentials.setVisible(true);
                dispose(); // Closes the current window (Dashboard)
            }
        });
        btnAdmin.setBounds(166, 127, 120, 21);
        contentPane.add(btnAdmin);

        JButton btnPlayer = new JButton("Players Panel");
        btnPlayer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Opens the Players Panel when the button is clicked
                Homepage homepage = new Homepage();
                homepage.setVisible(true);
                dispose(); // Closes the current window (Dashboard)
            }
        });
        btnPlayer.setBounds(166, 165, 120, 21);
        contentPane.add(btnPlayer);

        JButton btnExit = new JButton("Exit");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Exits the application when the button is clicked
                System.exit(0);
            }
        });
        btnExit.setBounds(353, 232, 85, 21);
        contentPane.add(btnExit);
    }
}
