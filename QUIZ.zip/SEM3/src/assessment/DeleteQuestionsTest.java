package assessment;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.*;
import javax.swing.*;

/**
 * Unit test for the {@link DeleteQuestions} class using JUnit 5.
 * This class tests the functionality of deleting a question from the quiz system by its ID.
 * It verifies whether the correct question ID is passed to the database for deletion.
 */
class DeleteQuestionsTest {

    private DeleteQuestions deleteQuestions;
    private CompetitionDB mockDb;

    // A container for tracking the data being passed to deleteQuestionById
    private String questionIdPassed;

    /**
     * Sets up the test environment before each test case.
     * Initializes a mock database and a test instance of {@link DeleteQuestions}.
     */
    @BeforeEach
    void setUp() {
        // Mock the database manager
        mockDb = new CompetitionDB() {
            @Override
            public boolean deleteQuestionById(String questionId) {
                // Track the value passed to the method
                questionIdPassed = questionId;
                return questionId != null && !questionId.isEmpty();
            }

            @Override
            public void closeConnection() {
                // Mocked closeConnection method
            }
        };

        // Create the DeleteQuestions object and inject the mockDb
        deleteQuestions = new DeleteQuestions() {
            private static final long serialVersionUID = 1L;

            @Override
            protected CompetitionDB getDbManager() {
                return mockDb; // Override to use the mock DB
            }
        };

        // Set up fields for testing
        deleteQuestions.questionIdField = new JTextField();
        deleteQuestions.deleteButton = new JButton("Delete");
        deleteQuestions.cancelButton = new JButton("Exit");

        // Simulate the window creation
        deleteQuestions.setSize(400, 200);
        deleteQuestions.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Add ActionListener to the delete button inside DeleteQuestions
        deleteQuestions.deleteButton.addActionListener(e -> {
            String questionId = deleteQuestions.questionIdField.getText().trim();
            deleteQuestions.getDbManager().deleteQuestionById(questionId);
        });
    }
    
    /**
     * Tests the deletion of a question with a valid ID.
     * It simulates user input and verifies that the expected question ID is passed to the database for deletion.
     */
    @Test
    void testDeleteQuestion_ValidId() {
        // Set valid input data
        deleteQuestions.questionIdField.setText("101");

        // Simulate clicking the Delete button
        deleteQuestions.deleteButton.doClick();

        // Assert that the valid Question ID is passed to the mock method
        assertEquals("101", questionIdPassed);
    }

    

   
}
