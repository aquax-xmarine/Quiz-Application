package assessment;

import java.sql.SQLException;
import java.util.*;

/**
 * This class provides a console-based user interface for managing and viewing competitor data,
 * generating reports, and interacting with the database.
 */
public class ConsoleView {

    /**
     * The entry point for the Competitor Management System.
     * This method provides the menu interface for the user to interact with.
     * 
     * @param args Command line arguments (unused).
     */
    public static void main(String[] args) {
        // Initialize the scanner, database manager, and leaderboard user objects
        Scanner scanner = new Scanner(System.in);
        int choice;

        CompetitionDB dbManager = new CompetitionDB();  
        LeaderboardUser leaderboard = new LeaderboardUser();

        do {
            // Display the main menu and prompt the user for a choice
            System.out.println("\n--- Competitor Management System ---");
            System.out.println("1. Generate Full Report");
            System.out.println("2. Display Top Performer");
            System.out.println("3. Generate Statistics");
            System.out.println("4. Search Competitor by ID");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            // Perform actions based on the user's choice
            switch (choice) {
                case 1:
                    ConsoleView view = new ConsoleView();
                    view.fetchCompetitorData(dbManager, scanner);
                    break;
                case 2:
                    displayTopPerformers(leaderboard);
                    break;
                case 3:
                    displayTotalPlayers(dbManager);
                    List<Competitor> frequency = dbManager.getLeaderboard("All");
                    displayFrequencyReport(frequency);
                    break;
                case 4:
                    searchCompetitorByID(dbManager, scanner);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 5);

        scanner.close();
    }

    /**
     * Fetches and displays the competitor data from the database.
     * 
     * @param dbManager The database manager to fetch the competitor reports.
     * @param scanner The scanner to take user input.
     */
    private void fetchCompetitorData(CompetitionDB dbManager, Scanner scanner) {
        // Get competitor data from the database (returns List<CompetitorReport>)
        List<CompetitorReport> reports = dbManager.getReports("All");

        // Extract competitors and highest scores from the reports
        List<Competitor> competitors = new LinkedList<>();
        List<Integer> highestScores = new LinkedList<>();

        for (CompetitorReport report : reports) {
            competitors.add(report.getCompetitor());
            highestScores.add(report.getHighestScore());
        }

        // Call the displayCompetitors method to print the data in the console
        displayCompetitors(competitors, highestScores);
    }

    /**
     * Displays a list of competitors with their scores and details.
     * 
     * @param competitors A list of competitor objects to display.
     * @param highestScores A list of highest scores corresponding to each competitor.
     */
    private void displayCompetitors(List<Competitor> competitors, List<Integer> highestScores) {
        String[] columnNames = {"ID", "First Name", "Last Name", "Age", "Level", "Score1", "Score2", "Score3", "Score4", "Score5", "Highest Score"};

        // Print the column headers
        for (String column : columnNames) {
            System.out.printf("%-15s", column); // Adjust width for alignment
        }
        System.out.println();  // New line after the header

        // Print a separator line
        for (int i = 0; i < columnNames.length; i++) {
            System.out.print("-----------------");
        }
        System.out.println();  // New line after the separator

        // Print the data for each competitor
        for (int i = 0; i < competitors.size(); i++) {
            Competitor c = competitors.get(i);
            int highestScore = highestScores.get(i);  // Get the highest score for this competitor

            System.out.printf("%-15d", c.getCompetitorID());   // Competitor ID
            System.out.printf("%-15s", c.getCompetitorName().getFirstName());  // First Name
            System.out.printf("%-15s", c.getCompetitorName().getLastName());   // Last Name
            System.out.printf("%-15d", c.getAge());   // Age
            System.out.printf("%-15s", c.getCompetitionLevel());  // Level

            // Print the scores
            for (int score : c.getScoreArray()) {
                System.out.printf("%-15d", score);
            }

            System.out.printf("%-15d", highestScore);   // Highest Score
            System.out.println();  // New line after each competitor's data
        }
    }

    /**
     * Displays the total number of players in the competition.
     * 
     * @param dbManager The database manager to get the total number of players.
     */
    private static void displayTotalPlayers(CompetitionDB dbManager) {
        int totalPlayers = dbManager.getTotalPlayers();
        System.out.println("\n--- Total Players ---");
        System.out.println("Total Players: " + totalPlayers);
    }

    /**
     * Displays a frequency report of the competitors' scores.
     * 
     * @param leaderboard A list of competitors used to calculate score frequencies.
     */
    private static void displayFrequencyReport(List<Competitor> leaderboard) {
        Map<Integer, Integer> scoreFrequency = new HashMap<>();

        // Calculate the frequency of each score
        for (Competitor competitor : leaderboard) {
            for (int score : competitor.getScoreArray()) {
                scoreFrequency.put(score, scoreFrequency.getOrDefault(score, 0) + 1);
            }
        }

        List<Integer> sortedScores = new ArrayList<>(scoreFrequency.keySet());
        Collections.sort(sortedScores);

        System.out.println("\n--- Frequency Report ---");
        System.out.println("Score | Frequency");
        System.out.println("-----------------");

        // Print the frequency report
        for (int score : sortedScores) {
            System.out.printf("%5d | %5d%n", score, scoreFrequency.get(score));
        }
    }

    /**
     * Displays the top performers in the competition.
     * 
     * @param leaderboard The leaderboard user object to fetch top performers.
     */
    private static void displayTopPerformers(LeaderboardUser leaderboard) {
        System.out.println("\n--- Top Performers ---");
        LeaderboardUser.TopPerformers topPerformers = leaderboard.getTopPerformers("All");

        if (topPerformers.beginner != null) {
            System.out.printf("Top Performer (Beginner): %s - Score: %.1f%n",
                    topPerformers.beginner.getCompetitorName().getFullName(),
                    topPerformers.beginner.getOverallScore());
        } else {
            System.out.println("Top Performer (Beginner): N/A");
        }

        if (topPerformers.intermediate != null) {
            System.out.printf("Top Performer (Intermediate): %s - Score: %.1f%n",
                    topPerformers.intermediate.getCompetitorName().getFullName(),
                    topPerformers.intermediate.getOverallScore());
        } else {
            System.out.println("Top Performer (Intermediate): N/A");
        }

        if (topPerformers.advanced != null) {
            System.out.printf("Top Performer (Advanced): %s - Score: %.1f%n",
                    topPerformers.advanced.getCompetitorName().getFullName(),
                    topPerformers.advanced.getOverallScore());
        } else {
            System.out.println("Top Performer (Advanced): N/A");
        }
    }

    /**
     * Searches for a competitor by their ID and displays their details.
     * 
     * @param dbManager The database manager to fetch the competitor's details.
     * @param scanner The scanner to take user input.
     */
    private static void searchCompetitorByID(CompetitionDB dbManager, Scanner scanner) {
        System.out.print("\nEnter Competitor ID: ");
        int competitorID;

        try {
            competitorID = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            // Fetch and display competitor details
            Competitor competitor = dbManager.getCompetitorDetailsAndScores(competitorID);

            if (competitor != null) {
                System.out.println("\n--- Competitor Details ---");
                System.out.println("ID: " + competitor.getCompetitorID());
                System.out.println("Name: " + competitor.getCompetitorName().getFullName());
                System.out.println("Age: " + competitor.getAge());
                System.out.println("Level: " + competitor.getCompetitionLevel());
                System.out.println("Scores: " + Arrays.toString(competitor.getScoreArray()));
            } else {
                System.out.println("No competitor found with ID: " + competitorID);
            }

        } catch (InputMismatchException e) {
            System.out.println("Invalid input! Please enter a valid numeric ID.");
            scanner.nextLine(); // Clear the buffer
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
            e.printStackTrace(); // Optional: Print stack trace for debugging
        }
    }
}
