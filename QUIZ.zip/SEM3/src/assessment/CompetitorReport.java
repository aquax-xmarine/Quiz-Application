package assessment;

/**
 * Represents a report for a competitor, including their details and their highest score.
 */
public class CompetitorReport {
    
    private Competitor competitor;
    private int highestScore;

    /**
     * Constructor for creating a CompetitorReport.
     * 
     * @param competitor The Competitor object that holds the competitor's details.
     * @param highestScore The highest score achieved by the competitor.
     */
    public CompetitorReport(Competitor competitor, int highestScore) {
        this.competitor = competitor;
        this.highestScore = highestScore;
    }

    /**
     * Gets the competitor associated with this report.
     * 
     * @return The Competitor object containing the competitor's details.
     */
    public Competitor getCompetitor() {
        return competitor;
    }

    /**
     * Gets the highest score achieved by the competitor.
     * 
     * @return The highest score of the competitor.
     */
    public int getHighestScore() {
        return highestScore;
    }
}
