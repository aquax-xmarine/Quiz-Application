package assessment;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.*;

/**
 * This class represents the TableReport JFrame where detailed data about competitors can be viewed.
 * It allows the user to filter competitors by their competition level (Beginner, Intermediate, Advanced, or All).
 * The competitors' data, including scores, is displayed in a table.
 */
public class TableReport extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JButton btnBack;
    private JButton btnExit;
    private JComboBox<String> levelDropdown;
    private JTable competitorTable;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    TableReport frame = new TableReport();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public TableReport() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 927, 627); // Increase height for frequency report
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Title of the frame
        JLabel frame = new JLabel("Table Report");
        frame.setFont(new Font("Viner Hand ITC", Font.PLAIN, 30));
        frame.setBounds(359, 26, 271, 45);
        contentPane.add(frame);

        // Back button to navigate to StatisticalReport screen
        btnBack = new JButton("Back");
        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                StatisticalReport statisticalReport = new StatisticalReport();
                statisticalReport.setVisible(true);
                dispose();
            }
        });
        btnBack.setBounds(818, 509, 85, 21);
        contentPane.add(btnBack);

        // Exit button to close the application
        btnExit = new JButton("Exit");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        btnExit.setBounds(818, 540, 85, 21);
        contentPane.add(btnExit);

        // Dropdown for filtering competitors based on their level
        levelDropdown = new JComboBox<>(new String[]{"All", "Beginner", "Intermediate", "Advanced"});
        levelDropdown.setBounds(30, 50, 200, 30);
        contentPane.add(levelDropdown);

        // Table to display competitor data
        competitorTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(competitorTable);
        scrollPane.setBounds(30, 100, 861, 384);
        contentPane.add(scrollPane);

        // Add event listener to fetch and display data based on selected level
        levelDropdown.addActionListener(e -> fetchCompetitorData());
        fetchCompetitorData(); // Initial data loading
    }

    /**
     * Fetch competitor data from the database based on the selected competition level.
     * This method updates the table to display the relevant data.
     */
    private void fetchCompetitorData() {
        CompetitionDB dbManager = new CompetitionDB();
        String selectedLevel = (String) levelDropdown.getSelectedItem();

        // Get competitor data from the database (returns List<CompetitorReport>)
        List<CompetitorReport> reports = dbManager.getReports(selectedLevel);

        // Extract competitors and highest scores from the reports
        List<Competitor> competitors = new LinkedList<>();
        List<Integer> highestScores = new LinkedList<>();

        for (CompetitorReport report : reports) {
            competitors.add(report.getCompetitor());
            highestScores.add(report.getHighestScore());
        }

        // Pass competitors and highestScores to display method
        displayCompetitors(competitors, highestScores);
    }

    /**
     * Display the fetched competitor data in the table.
     *
     * @param competitors   List of competitors whose data needs to be displayed
     * @param highestScores List of highest scores for the corresponding competitors
     */
    private void displayCompetitors(List<Competitor> competitors, List<Integer> highestScores) {
        String[] columnNames = {"ID", "First Name", "Last Name", "Age", "Level", "Score1", "Score2", "Score3", "Score4", "Score5", "Highest Score"};
        Object[][] data = new Object[competitors.size()][11]; // Increased to 11 to accommodate the highest score

        for (int i = 0; i < competitors.size(); i++) {
            Competitor c = competitors.get(i);
            int highestScore = highestScores.get(i); // Get the highest score for this competitor

            // Fill the data array with competitor information
            data[i][0] = c.getCompetitorID();
            data[i][1] = c.getCompetitorName().getFirstName();
            data[i][2] = c.getCompetitorName().getLastName();
            data[i][3] = c.getAge();
            data[i][4] = c.getCompetitionLevel();
            data[i][5] = c.getScoreArray()[0];
            data[i][6] = c.getScoreArray()[1];
            data[i][7] = c.getScoreArray()[2];
            data[i][8] = c.getScoreArray()[3];
            data[i][9] = c.getScoreArray()[4];
            data[i][10] = highestScore; // Set highest score
        }

        // Set the data into the table model
        DefaultTableModel model = new DefaultTableModel(data, columnNames);
        competitorTable.setModel(model);
    }
}
