package assessment;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;

/**
 * SummaryStatistics is a JFrame-based GUI class that displays summary statistics
 * about competitors in a competition. It shows the total number of players, 
 * top performers for each difficulty level (Beginner, Intermediate, Advanced), 
 * and a frequency report of scores in a table.
 * The statistics are fetched from a database using the CompetitionDB and LeaderboardUser classes.
 * 
 * The class allows navigation to the Admin Panel and provides the option to exit the application.
 * 
 * @author Your Name
 */
public class SummaryStatistics extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel totalPlayersLabel;
    private JLabel topPerformerBeginnerLabel;
    private JLabel topPerformerIntermediateLabel;
    private JLabel topPerformerAdvancedLabel;
    private JTable frequencyTable;  // Table to display frequency report
    private JButton btnBack;
    private JButton btnExit;
    private JLabel lblNewLabel;
    private JLabel lblNewLabel_1;
    private JLabel lblNewLabel_2;

    /**
     * Launch the SummaryStatistics application.
     * 
     * @param args The command line arguments (not used).
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                	SummaryStatistics frame = new SummaryStatistics();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Constructs the SummaryStatistics frame.
     * This method sets up the GUI components, fetches data from the database,
     * and displays summary statistics about players and their performance.
     */
    public SummaryStatistics() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 861, 595); // Increase height for frequency report
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Label to display total players
        totalPlayersLabel = new JLabel("Total Players: 0");
        totalPlayersLabel.setFont(new Font("Tahoma", Font.PLAIN, 10));
        totalPlayersLabel.setBounds(30, 102, 200, 40);
        contentPane.add(totalPlayersLabel);
        
        // Labels for top performers
        topPerformerBeginnerLabel = new JLabel("Top Performer for Beginner level: N/A");
        topPerformerBeginnerLabel.setFont(new Font("Tahoma", Font.PLAIN, 10));
        topPerformerBeginnerLabel.setBounds(30, 152, 694, 30);
        contentPane.add(topPerformerBeginnerLabel);

        topPerformerIntermediateLabel = new JLabel("Top Performer for Intermediate level: N/A");
        topPerformerIntermediateLabel.setFont(new Font("Tahoma", Font.PLAIN, 10));
        topPerformerIntermediateLabel.setBounds(30, 202, 694, 30);
        contentPane.add(topPerformerIntermediateLabel);

        topPerformerAdvancedLabel = new JLabel("Top Performer for Advanced level: N/A");
        topPerformerAdvancedLabel.setFont(new Font("Tahoma", Font.PLAIN, 10));
        topPerformerAdvancedLabel.setBounds(30, 252, 694, 30);
        contentPane.add(topPerformerAdvancedLabel);

        // Fetch total players from the database
        CompetitionDB dbManager = new CompetitionDB();
        int totalPlayers = dbManager.getTotalPlayers();
        totalPlayersLabel.setText("Total Players: " + totalPlayers);
        
        JLabel frame = new JLabel("Summary Statistics");
        frame.setFont(new Font("Viner Hand ITC", Font.PLAIN, 30));
        frame.setBounds(271, 45, 330, 45);
        contentPane.add(frame);
        
        // Fetch leaderboard data directly from the database
        List<Competitor> frequency = dbManager.getLeaderboard("All");

        // Fetch top performers for each level from the leaderboard
        LeaderboardUser leaderboard = new LeaderboardUser();
        LeaderboardUser.TopPerformers topPerformers = leaderboard.getTopPerformers("All"); // Assuming 'All' fetches for all levels
        
        // Update the labels with the top performers' details
        if (topPerformers.beginner != null) {
            String topBeginnerName = topPerformers.beginner.getCompetitorName().getFullName(); // Get full name
            double topBeginnerScore = topPerformers.beginner.getOverallScore(); // Get overall score
            topPerformerBeginnerLabel.setText(String.format("Competitor with the highest score in beginner level: %s with an overall score of %.1f", topBeginnerName, topBeginnerScore));
        }
        if (topPerformers.intermediate != null) {
            String topIntermediateName = topPerformers.intermediate.getCompetitorName().getFullName(); // Get full name
            double topIntermediateScore = topPerformers.intermediate.getOverallScore(); // Get overall score
            topPerformerIntermediateLabel.setText(String.format("Competitor with the highest score in intermediate level: %s with an overall score of %.1f", topIntermediateName, topIntermediateScore));
        }
        if (topPerformers.advanced != null) {
            String topAdvancedName = topPerformers.advanced.getCompetitorName().getFullName(); // Get full name
            double topAdvancedScore = topPerformers.advanced.getOverallScore(); // Get overall score
            topPerformerAdvancedLabel.setText(String.format("Competitor with the highest score in advanced level: %s with an overall score of %.1f", topAdvancedName, topAdvancedScore));
        }
        
        // Add a table to display the frequency report
        frequencyTable = new JTable();
        frequencyTable.setBounds(30, 402, 373, 101);
        contentPane.add(frequencyTable);

        // Call method to display frequency report
        displayFrequencyReport(frequency);

        
        btnBack = new JButton("Back");
        btnBack.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		AdminPanel adminPanel = new AdminPanel();
				adminPanel.setVisible(true);
				dispose();
        	}
        });
        btnBack.setBounds(734, 501, 85, 21);
        contentPane.add(btnBack);
        
        btnExit = new JButton("Exit");
        btnExit.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		System.exit(0);
        	}
        });
        btnExit.setBounds(734, 532, 85, 21);
        contentPane.add(btnExit);
        
        lblNewLabel = new JLabel("Score");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 10));
        lblNewLabel.setBounds(87, 371, 85, 21);
        contentPane.add(lblNewLabel);
        
        lblNewLabel_1 = new JLabel("Frequency");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 10));
        lblNewLabel_1.setBounds(270, 371, 133, 21);
        contentPane.add(lblNewLabel_1);
        
        lblNewLabel_2 = new JLabel("Frequency Report");
        lblNewLabel_2.setFont(new Font("Viner Hand ITC", Font.PLAIN, 20));
        lblNewLabel_2.setBounds(116, 322, 187, 39);
        contentPane.add(lblNewLabel_2);
        
       

        
    }
    
    
    /**
     * Generates and displays a frequency report in a table format.
     * The report shows the frequency of each score across all competitors.
     * 
     * @param leaderboard List of competitors whose scores will be analyzed.
     */
    public void displayFrequencyReport(List<Competitor> leaderboard) {
        Map<Integer, Integer> scoreFrequency = new HashMap<>();

        // Count the frequency of each score across all competitors
        for (Competitor competitor : leaderboard) {
            for (int score : competitor.getScoreArray()) {
                scoreFrequency.put(score, scoreFrequency.getOrDefault(score, 0) + 1);
            }
        }

        // Sort the scores in ascending order
        List<Integer> sortedScores = new ArrayList<>(scoreFrequency.keySet());
        Collections.sort(sortedScores);

        // Prepare data for the table
        String[] columnNames = {"Score", "Frequency"};
        Object[][] data = new Object[sortedScores.size()][2];

        // Populate the table data with scores and their frequencies
        for (int i = 0; i < sortedScores.size(); i++) {
            int score = sortedScores.get(i);
            data[i][0] = score;
            data[i][1] = scoreFrequency.get(score);
        }

        // Set the table model
        DefaultTableModel model = new DefaultTableModel(data, columnNames);
        frequencyTable.setModel(model);
    }


    
} 