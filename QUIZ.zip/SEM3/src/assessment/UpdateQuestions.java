package assessment;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * This class provides a GUI for updating questions in the competition database.
 * It allows the user to input and modify question details, including the question text, options, correct answer, and level.
 * The data is then updated in the database upon clicking the 'Update' button.
 */
public class UpdateQuestions extends JFrame {

    private static final long serialVersionUID = 1L;

    public JTextField questionIDField, questionField, optionAField, optionBField, optionCField, optionDField;
    public JComboBox<String> correctAnswerBox, levelBox;
    public JButton updateButton, cancelButton;
    public CompetitionDB dbManager;
    public JButton backButton;

    /**
     * Constructor that initializes the GUI components and sets up event listeners.
     */
    public UpdateQuestions() {
        dbManager = new CompetitionDB();

        setTitle("Update Question");
        setSize(430, 415);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        // Question ID Input (to identify the question to update)
        JLabel label = new JLabel("Question ID:");
        label.setBounds(16, 4, 190, 35);
        getContentPane().add(label);
        questionIDField = new JTextField();
        questionIDField.setBounds(216, 4, 190, 35);
        getContentPane().add(questionIDField);

        // Question Input
        JLabel label_1 = new JLabel("Question:");
        label_1.setBounds(16, 44, 190, 35);
        getContentPane().add(label_1);
        questionField = new JTextField();
        questionField.setBounds(216, 44, 190, 35);
        getContentPane().add(questionField);

        JLabel label_2 = new JLabel("Option A:");
        label_2.setBounds(16, 84, 190, 35);
        getContentPane().add(label_2);
        optionAField = new JTextField();
        optionAField.setBounds(216, 84, 190, 35);
        getContentPane().add(optionAField);

        JLabel label_3 = new JLabel("Option B:");
        label_3.setBounds(16, 124, 190, 35);
        getContentPane().add(label_3);
        optionBField = new JTextField();
        optionBField.setBounds(216, 124, 190, 35);
        getContentPane().add(optionBField);

        JLabel label_4 = new JLabel("Option C:");
        label_4.setBounds(16, 164, 190, 35);
        getContentPane().add(label_4);
        optionCField = new JTextField();
        optionCField.setBounds(216, 164, 190, 35);
        getContentPane().add(optionCField);

        JLabel label_5 = new JLabel("Option D:");
        label_5.setBounds(16, 204, 190, 35);
        getContentPane().add(label_5);
        optionDField = new JTextField();
        optionDField.setBounds(216, 204, 190, 35);
        getContentPane().add(optionDField);

        // Correct Answer Drop down
        JLabel label_6 = new JLabel("Correct Answer:");
        label_6.setBounds(16, 244, 190, 35);
        getContentPane().add(label_6);
        correctAnswerBox = new JComboBox<>(new String[]{"A", "B", "C", "D"});
        correctAnswerBox.setBounds(216, 244, 190, 35);
        getContentPane().add(correctAnswerBox);

        // Level Drop down
        JLabel label_7 = new JLabel("Level:");
        label_7.setBounds(16, 284, 190, 35);
        getContentPane().add(label_7);
        levelBox = new JComboBox<>(new String[]{"Beginner", "Intermediate", "Advanced"});
        levelBox.setBounds(216, 284, 190, 35);
        getContentPane().add(levelBox);

        // Buttons
        updateButton = new JButton("Update");
        updateButton.setBounds(16, 333, 114, 35);
        cancelButton = new JButton("Exit");
        cancelButton.setBounds(156, 333, 104, 35);

        getContentPane().add(updateButton);
        getContentPane().add(cancelButton);

        // Back Button to return to the admin panel
        backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AdminPanel adminPanel = new AdminPanel();
                adminPanel.setVisible(true);
                dispose();
            }
        });
        backButton.setBounds(290, 333, 104, 35);
        getContentPane().add(backButton);

        // Button Actions
        updateButton.addActionListener(e -> updateQuestion());
        cancelButton.addActionListener(e -> {
            dbManager.closeConnection(); // Close DB connection when exiting
            dispose();
        });

        setLocationRelativeTo(null);
    }

    /**
     * Updates the question details in the database based on the input fields.
     * If any field is empty, an error message is shown.
     * If the update is successful, a success message is shown and fields are cleared.
     */
    private void updateQuestion() {
        String questionID = questionIDField.getText();
        String question = questionField.getText();
        String optionA = optionAField.getText();
        String optionB = optionBField.getText();
        String optionC = optionCField.getText();
        String optionD = optionDField.getText();
        String correctAnswer = correctAnswerBox.getSelectedItem().toString();
        String level = levelBox.getSelectedItem().toString();

        if (questionID.isEmpty() || question.isEmpty() || optionA.isEmpty() || optionB.isEmpty() || optionC.isEmpty() || optionD.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        boolean success = dbManager.updateQuestion(Integer.parseInt(questionID), question, optionA, optionB, optionC, optionD, correctAnswer, level);
        if (success) {
            JOptionPane.showMessageDialog(this, "Question updated successfully!");
            clearFields();
        } else {
            JOptionPane.showMessageDialog(this, "Error updating question!", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Clears all the input fields after a successful update.
     */
    private void clearFields() {
        questionIDField.setText("");
        questionField.setText("");
        optionAField.setText("");
        optionBField.setText("");
        optionCField.setText("");
        optionDField.setText("");
        correctAnswerBox.setSelectedIndex(0);
        levelBox.setSelectedIndex(0);
    }

    /**
     * Main method to run the UpdateQuestions frame.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new UpdateQuestions().setVisible(true));
    }

	public CompetitionDB getDbManager() {
		// TODO Auto-generated method stub
		return null;
	}
}
