package assessment;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

/**
 * SignIn class represents the login screen of the application.
 * It handles user input, validates the Competitor ID, 
 * and manages the navigation between different screens such as the quiz and leaderboard.
 */
public class SignIn extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtCompetitorID;
	private CompetitionDB dbManager;

	/**
     * Launch the application.
     * This method runs the GUI in a separate thread and initializes the SignIn screen.
     */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SignIn frame = new SignIn();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
     * Create the frame.
     * Initializes the components and sets up the event listeners for buttons.
     */
	public SignIn() {
		dbManager = new CompetitionDB();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 398);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel frame = new JLabel("Sign in");
		frame.setFont(new Font("Viner Hand ITC", Font.PLAIN, 30));
		frame.setBounds(164, 27, 125, 49);
		contentPane.add(frame);
		
		JLabel lblUsername = new JLabel("Competitor ID");
		lblUsername.setBounds(117, 101, 88, 13);
		contentPane.add(lblUsername);
		
		txtCompetitorID = new JTextField();
		txtCompetitorID.setBounds(215, 98, 96, 19);
		contentPane.add(txtCompetitorID);
		txtCompetitorID.setColumns(10);
		
		JButton btnSubmit = new JButton("Start Quiz");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String competitorIDStr = txtCompetitorID.getText();
                if (competitorIDStr.isEmpty()) {
                    // Handle case when the user didn't enter a first name
                    System.out.println("Please enter your ID.");
                    return;
                }

                
				// Retrieve user data from the database
                
                int competitorID = Integer.parseInt(competitorIDStr);
				User user = dbManager.getUserByID(competitorID);

                if (user != null) {
                	
                    // If user found, retrieve the id and level
                    String userLevel = user.getLevel();
                    	
                    // Check if all scores are filled
                    boolean allScoresFilled = dbManager.checkIfScoresFilled(competitorID);

                    if (allScoresFilled) {
                        // Show message if the maximum play limit is reached
                        JOptionPane.showMessageDialog(null, "Maximum play limit reached. You cannot play anymore.");
                    } else {
                        // Pass the id and level to the next screen (Quiz screen)
                        QuizGUI quizScreen = new QuizGUI(userLevel, competitorID);
                        quizScreen.setVisible(true);
                        dispose(); // Close the sign-in screen
                    }
                } else {
                    // Show a message if no user is found
                    System.out.println("No user found with that first name.");
                }
			}
		});
		btnSubmit.setBounds(139, 144, 157, 21);
		contentPane.add(btnSubmit);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Homepage homepage = new Homepage();
				homepage.setVisible(true);
				dispose();
			}
		});
		btnBack.setBounds(341, 297, 85, 21);
		contentPane.add(btnBack);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setBounds(341, 328, 85, 21);
		contentPane.add(btnExit);
		
		JButton btnViewShortDetails = new JButton("View Short Details");
		btnViewShortDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String competitorIDStr = txtCompetitorID.getText();
                if (competitorIDStr.isEmpty()) {
                    JOptionPane.showMessageDialog(SignIn.this, "Please enter your Competitor ID.");
                    return;
                }

                try {
                    int competitorID = Integer.parseInt(competitorIDStr);
                    Competitor competitor = dbManager.getCompetitorDetailsAndScores(competitorID);

                    if (competitor != null) {
                        String shortDetails = competitor.getShortDetails();
                        JOptionPane.showMessageDialog(SignIn.this, shortDetails, "Full Details", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(SignIn.this, "Competitor not found.");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(SignIn.this, "Invalid Competitor ID.");
                } catch (SQLException e1) {
                    JOptionPane.showMessageDialog(SignIn.this, "Database Error: " + e1.getMessage());
                    e1.printStackTrace();
                }
				
			}
		});
		btnViewShortDetails.setBounds(139, 175, 157, 21);
		contentPane.add(btnViewShortDetails);
		
		JButton btnViewfulldetails = new JButton("View Full Details");
		btnViewfulldetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String competitorIDStr = txtCompetitorID.getText();
                if (competitorIDStr.isEmpty()) {
                    JOptionPane.showMessageDialog(SignIn.this, "Please enter your Competitor ID.");
                    return;
                }

                try {
                    int competitorID = Integer.parseInt(competitorIDStr);
                    Competitor competitor = dbManager.getCompetitorDetailsAndScores(competitorID);

                    if (competitor != null) {
                        String fullDetails = competitor.getFullDetails();
                        JOptionPane.showMessageDialog(SignIn.this, fullDetails, "Full Details", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(SignIn.this, "Competitor not found.");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(SignIn.this, "Invalid Competitor ID.");
                } catch (SQLException e1) {
                    JOptionPane.showMessageDialog(SignIn.this, "Database Error: " + e1.getMessage());
                    e1.printStackTrace();
                }
			}
		});
		btnViewfulldetails.setBounds(139, 206, 157, 21);
		contentPane.add(btnViewfulldetails);
		
		JButton btnViewLeaderboard = new JButton("View Leaderboard");
		btnViewLeaderboard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LeaderboardUser leaderboardUser = new LeaderboardUser();
				leaderboardUser.setVisible(true);
				dispose();
			}
		});
		btnViewLeaderboard.setBounds(139, 237, 157, 21);
		contentPane.add(btnViewLeaderboard);
	}
}
