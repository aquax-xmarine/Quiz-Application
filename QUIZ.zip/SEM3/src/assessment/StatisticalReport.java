package assessment;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;

/**
 * StatisticalReport represents the report view screen for the application.
 * It allows the user to view various reports such as a table report, summary statistics, and navigate back to the admin panel.
 */
public class StatisticalReport extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JButton btnBack;
    private JButton btnExit;
    private JLabel lblNewLabel;

    /**
     * Launch the application.
     * This method runs the GUI in a separate thread and initializes the StatisticalReport screen.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    StatisticalReport frame = new StatisticalReport();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     * Initializes the components and sets up the event listeners for the buttons.
     */
    public StatisticalReport() {
        // Set the frame properties
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 584, 314); // Increase height for frequency report
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Button to navigate back to the admin panel
        btnBack = new JButton("Back");
        btnBack.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		AdminPanel adminPanel = new AdminPanel();
				adminPanel.setVisible(true);
				dispose(); // Close the current window
        	}
        });
        btnBack.setBounds(434, 200, 85, 21);
        contentPane.add(btnBack);
        
        // Button to exit the application
        btnExit = new JButton("Exit");
        btnExit.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		System.exit(0); // Exit the application
        	}
        });
        btnExit.setBounds(434, 227, 85, 21);
        contentPane.add(btnExit);
        
        // Button to view the table report
        JButton btnNewButton = new JButton("View Table");
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		TableReport tableReport = new TableReport();
        		tableReport.setVisible(true); // Open the table report
				dispose(); // Close the current window
        	}
        });
        btnNewButton.setBounds(193, 119, 198, 21);
        contentPane.add(btnNewButton);
        
        // Button to view summary statistics
        JButton btnViewSummaryStatistics = new JButton("View Summary Statistics");
        btnViewSummaryStatistics.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		SummaryStatistics summaryStatistics = new SummaryStatistics();
        		summaryStatistics.setVisible(true); // Open the summary statistics screen
				dispose(); // Close the current window
        	}
        });
        btnViewSummaryStatistics.setBounds(193, 153, 198, 21);
        contentPane.add(btnViewSummaryStatistics);
        
        // Label (currently not in use)
        JLabel label = new JLabel("New label");
        label.setBounds(313, 84, 54, -10);
        contentPane.add(label);
        
        // Title label for the report
        lblNewLabel = new JLabel("Report");
        lblNewLabel.setFont(new Font("Viner Hand ITC", Font.PLAIN, 30));
        lblNewLabel.setBounds(246, 37, 145, 49);
        contentPane.add(lblNewLabel);
    }
}
