package assessment;

/**
 * The {@code QuestionText} class represents a multiple-choice question.
 * It holds the question text, options, and the correct answer for a given question.
 */
public class QuestionText {

    private String questionText;
    private String optionA, optionB, optionC, optionD;
    private String correctAnswer;

    /**
     * Constructs a {@code QuestionText} object with the specified question, options, and correct answer.
     *
     * @param questionText The text of the question.
     * @param optionA      The first option for the question.
     * @param optionB      The second option for the question.
     * @param optionC      The third option for the question.
     * @param optionD      The fourth option for the question.
     * @param correctAnswer The correct answer for the question.
     */
    public QuestionText(String questionText, String optionA, String optionB, String optionC, String optionD, String correctAnswer) {
        this.questionText = questionText;
        this.optionA = optionA;
        this.optionB = optionB;
        this.optionC = optionC;
        this.optionD = optionD;
        this.correctAnswer = correctAnswer;
    }

    /**
     * Gets the question text.
     *
     * @return The text of the question.
     */
    public String getQuestionText() {
        return questionText;
    }

    /**
     * Gets the first option for the question.
     *
     * @return The first option.
     */
    public String getOptionA() {
        return optionA;
    }

    /**
     * Gets the second option for the question.
     *
     * @return The second option.
     */
    public String getOptionB() {
        return optionB;
    }

    /**
     * Gets the third option for the question.
     *
     * @return The third option.
     */
    public String getOptionC() {
        return optionC;
    }

    /**
     * Gets the fourth option for the question.
     *
     * @return The fourth option.
     */
    public String getOptionD() {
        return optionD;
    }

    /**
     * Gets the correct answer for the question.
     *
     * @return The correct answer.
     */
    public String getCorrectAnswer() {
        return correctAnswer;
    }
}
