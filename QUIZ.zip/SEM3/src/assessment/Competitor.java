package assessment;

/**
 * Represents a competitor in a competition, containing details such as competitor ID, name, competition level, age, and scores.
 * This class includes methods for retrieving, updating, and displaying competitor information, including overall score and highest score.
 */
public class Competitor {
    private int competitorID;
    private Name competitorName;
    private String competitionLevel;
    private int age;
    private int[] scores = new int[5];

    /**
     * Constructor to initialize a competitor with their details.
     * 
     * @param competitorID The ID of the competitor.
     * @param competitorName The name of the competitor.
     * @param competitionLevel The level of the competition the competitor is in.
     * @param age The age of the competitor.
     * @param scores The scores of the competitor in the competition.
     */
    public Competitor(int competitorID, Name competitorName, String competitionLevel, int age, int[] scores) {
        this.competitorID = competitorID;
        this.competitorName = competitorName;
        this.competitionLevel = competitionLevel;
        this.age = age;
        this.scores = scores;
    }

    // Getter and Setter methods

    /**
     * Gets the ID of the competitor.
     * 
     * @return The competitor's ID.
     */
    public int getCompetitorID() {
        return competitorID;
    }

    /**
     * Sets the ID of the competitor.
     * 
     * @param competitorID The competitor's ID.
     */
    public void setCompetitorID(int competitorID) {
        this.competitorID = competitorID;
    }

    /**
     * Gets the name of the competitor.
     * 
     * @return The competitor's name.
     */
    public Name getCompetitorName() {
        return competitorName;
    }

    /**
     * Sets the name of the competitor.
     * 
     * @param competitorName The competitor's name.
     */
    public void setCompetitorName(Name competitorName) {
        this.competitorName = competitorName;
    }

    /**
     * Gets the competition level of the competitor.
     * 
     * @return The competition level of the competitor.
     */
    public String getCompetitionLevel() {
        return competitionLevel;
    }

    /**
     * Sets the competition level of the competitor.
     * 
     * @param competitionLevel The competition level of the competitor.
     */
    public void setCompetitionLevel(String competitionLevel) {
        this.competitionLevel = competitionLevel;
    }

    /**
     * Gets the age of the competitor.
     * 
     * @return The age of the competitor.
     */
    public int getAge() {
        return age;
    }

    /**
     * Sets the age of the competitor.
     * 
     * @param age The age of the competitor.
     */
    public void setAge(int age) {
        this.age = age;
    }

    /**
     * Gets the array of scores for the competitor.
     * 
     * @return The array of scores.
     */
    public int[] getScoreArray() {
        return scores;
    }

    /**
     * Sets the scores of the competitor.
     * 
     * @param scores The array of scores.
     */
    public void setScores(int[] scores) {
        this.scores = scores;
    }

    /**
     * Calculates and returns the overall score of the competitor (average of 5 scores).
     * 
     * @return The overall score as a double.
     */
    public double getOverallScore() {
        if (scores == null || scores.length == 0) {
            return 0; // Return 0 if no scores
        }
        int total = 0;
        for (int score : scores) {
            total += score;
        }
        return total / (double) scores.length;
    }

    /**
     * Sets the competitor's details (name, competition level, and age).
     * 
     * @param competitorName The name of the competitor.
     * @param competitionLevel The competition level of the competitor.
     * @param age The age of the competitor.
     */
    public void setCompetitorDetails(Name competitorName, String competitionLevel, int age) {
        this.competitorName = competitorName;
        this.competitionLevel = competitionLevel;
        this.age = age;
    }

    /**
     * Returns full details of the competitor including their ID, name, competition level, scores, overall score, and highest score.
     * 
     * @return A string containing the full details of the competitor.
     */
    public String getFullDetails() {
        StringBuilder details = new StringBuilder();
        details.append("Full Details for CompetitorID ").append(competitorID).append(".\n");
        details.append("CompetitorID: ").append(competitorID).append(", Name: ").append(competitorName.getFullName()).append(".\n");
        details.append(competitorName.getFirstName()).append(" is a ").append(competitionLevel).append(" and received these scores: ");

        if (scores != null && scores.length > 0) {
            for (int i = 0; i < scores.length; i++) {
                details.append(scores[i]);
                if (i < scores.length - 1) {
                    details.append(", ");
                }
            }
            details.append(".\n");
        } else {
            details.append("No scores recorded.\n");
        }

        details.append("This gives ").append(competitorName.getFirstName()).append(" an overall score of ").append(String.format("%.1f", getOverallScore())).append(".\n");
        
        int highestScore = getHighestScore();
        details.append("Highest score: ").append(highestScore).append(".\n");

        return details.toString();
    }

    /**
     * Calculates and returns the highest score of the competitor.
     * 
     * @return The highest score as an integer.
     */
    public int getHighestScore() {
        if (scores == null || scores.length == 0) {
            return 0;
        }
        int highest = scores[0];
        for (int score : scores) {
            if (score > highest) {
                highest = score;
            }
        }
        return highest;
    }

    /**
     * Returns short details of the competitor, including their ID, initials, and overall score.
     * 
     * @return A string containing the short details of the competitor.
     */
    public String getShortDetails() {
        StringBuilder details = new StringBuilder();
        details.append("Short Details for CompetitorID ").append(competitorID).append(".\n");
        details.append("CN ").append(competitorID).append(" (").append(competitorName.getInitials()).append(") has an overall score of ").append(String.format("%.1f", getOverallScore())).append(".");
        return details.toString();
    }

    @Override
    public String toString() {
        return String.format("ID: %d | Name: %s | Level: %s | Age: %d | Overall Score: %.1f",
                competitorID, competitorName.getFullName(), competitionLevel, age, getOverallScore());
    }
}

