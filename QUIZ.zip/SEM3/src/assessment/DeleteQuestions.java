package assessment;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * The DeleteQuestions class represents a JFrame window that allows the user to delete a question
 * from a database by entering its Question ID. The window provides input fields for the Question ID,
 * and buttons to delete the question, exit the window, or return to the Admin Panel.
 * 
 * <p>The class communicates with the database via the {@link CompetitionDB} class to perform the deletion
 * of the question. If the deletion is successful, a confirmation message is displayed. If there is an error,
 * an error message is shown.</p>
 */
public class DeleteQuestions extends JFrame {
    private static final long serialVersionUID = 1L;
    public JTextField questionIdField;
    public JButton deleteButton, cancelButton;
    public CompetitionDB dbManager;
    public JButton backButton;

    /**
     * Constructs the DeleteQuestions window.
     * Initializes the layout, labels, input fields, buttons, and sets up the actions for the buttons.
     * It also creates an instance of {@link CompetitionDB} to manage database operations.
     */
    public DeleteQuestions() {
        dbManager = new CompetitionDB();

        setTitle("Delete Question");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        // Question ID Input
        JLabel label = new JLabel("Enter Question ID to Delete:");
        label.setBounds(0, 10, 190, 51);
        getContentPane().add(label);
        questionIdField = new JTextField();
        questionIdField.setBounds(186, 10, 190, 51);
        getContentPane().add(questionIdField);

        // Buttons
        deleteButton = new JButton("Delete");
        deleteButton.setBounds(0, 71, 122, 51);
        cancelButton = new JButton("Exit");
        cancelButton.setBounds(132, 71, 112, 51);

        getContentPane().add(deleteButton);
        getContentPane().add(cancelButton);
        
        backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Opens the Admin Panel when the button is clicked
                AdminPanel adminPanel = new AdminPanel();
                adminPanel.setVisible(true);
                dispose();  // Closes the current window (DeleteQuestions)
            }
        });
        backButton.setBounds(264, 71, 112, 51);
        getContentPane().add(backButton);

        // Button Actions
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteQuestion();
            }
        });
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dbManager.closeConnection();
                dispose();  // Closes the current window (DeleteQuestions)
            }
        });

        setLocationRelativeTo(null);  // Centers the window
    }

    /**
     * Deletes the question specified by the entered Question ID.
     * If the ID is empty, an error message is displayed.
     * If the deletion is successful, a success message is shown, and the input field is cleared.
     * If there is an error during deletion, an error message is displayed.
     */
    private void deleteQuestion() {
        String questionId = questionIdField.getText().trim();

        if (questionId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Question ID is required!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        boolean success = dbManager.deleteQuestionById(questionId);
        if (success) {
            JOptionPane.showMessageDialog(this, "Question deleted successfully!");
            questionIdField.setText("");  // Clears the field
        } else {
            JOptionPane.showMessageDialog(this, "Error deleting question!", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Launches the DeleteQuestions window.
     * This method is called to initialize and display the DeleteQuestions window.
     *
     * @param args Command-line arguments passed to the application (not used in this method).
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new DeleteQuestions().setVisible(true));
    }

	protected CompetitionDB getDbManager() {
		// TODO Auto-generated method stub
		return null;
	}
}
