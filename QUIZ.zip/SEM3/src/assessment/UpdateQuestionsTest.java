package assessment;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.*;
import javax.swing.*;

/**
 * Unit test for the {@link UpdateQuestions} class using JUnit 5.
 * This class tests the update functionality for quiz questions, ensuring that valid data is processed correctly
 * when a user attempts to update a question.
 */
class UpdateQuestionsTest {

    private UpdateQuestions updateQuestions;
    private CompetitionDB mockDb;

    // A container for tracking the data being passed to updateQuestion
    private int questionIDPassed;
    private String questionPassed;
    private String optionAPassed;
    private String optionBPassed;
    private String optionCPassed;
    private String optionDPassed;
    private String correctAnswerPassed;
    private String levelPassed;

    /**
     * Sets up the test environment before each test case.
     * Initializes the UpdateQuestions object, the mock database, and the UI components for interaction.
     * This method is executed before each test case.
     */
    @BeforeEach
    void setUp() {
        // Mock the database manager
        mockDb = new CompetitionDB() {
            @Override
            public boolean updateQuestion(int questionID, String question, String optionA, String optionB, String optionC, String optionD, String correctAnswer, String level) {
                // Track the values passed to the method
                questionIDPassed = questionID;
                questionPassed = question;
                optionAPassed = optionA;
                optionBPassed = optionB;
                optionCPassed = optionC;
                optionDPassed = optionD;
                correctAnswerPassed = correctAnswer;
                levelPassed = level;
                return questionID > 0 && !question.isEmpty() && !optionA.isEmpty() && !optionB.isEmpty() && !optionC.isEmpty() && !optionD.isEmpty();
            }
        };

        // Create the UpdateQuestions object and inject the mockDb
        updateQuestions = new UpdateQuestions() {
            private static final long serialVersionUID = 1L;

            @Override
			public CompetitionDB getDbManager() {
                return mockDb; // Override to use the mock DB
            }
        };

        // Set up fields for testing
        updateQuestions.questionIDField = new JTextField();
        updateQuestions.questionField = new JTextField();
        updateQuestions.optionAField = new JTextField();
        updateQuestions.optionBField = new JTextField();
        updateQuestions.optionCField = new JTextField();
        updateQuestions.optionDField = new JTextField();
        updateQuestions.correctAnswerBox = new JComboBox<>(new String[]{"A", "B", "C", "D"});
        updateQuestions.levelBox = new JComboBox<>(new String[]{"Beginner", "Intermediate", "Advanced"});
        updateQuestions.updateButton = new JButton("Update");

        // Simulate the window creation
        updateQuestions.setSize(430, 415);
        updateQuestions.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
     // Add ActionListener to the button inside the UpdateQuestions class
        updateQuestions.updateButton.addActionListener(e -> {
            int questionID = Integer.parseInt(updateQuestions.questionIDField.getText().trim());
            String question = updateQuestions.questionField.getText().trim();
            String optionA = updateQuestions.optionAField.getText().trim();
            String optionB = updateQuestions.optionBField.getText().trim();
            String optionC = updateQuestions.optionCField.getText().trim();
            String optionD = updateQuestions.optionDField.getText().trim();
            String correctAnswer = (String) updateQuestions.correctAnswerBox.getSelectedItem();
            String level = (String) updateQuestions.levelBox.getSelectedItem();

            updateQuestions.getDbManager().updateQuestion(questionID, question, optionA, optionB, optionC, optionD, correctAnswer, level);
        });

    }

    /**
     * Tests the update functionality of the quiz question with valid input data.
     * It simulates the user updating a question with correct data and clicking the update button.
     */
    @Test
    void testUpdateQuestion_ValidData() {
        // Set valid input data
        updateQuestions.questionIDField.setText("1");
        updateQuestions.questionField.setText("What is Java?");
        updateQuestions.optionAField.setText("Programming Language");
        updateQuestions.optionBField.setText("Fruit");
        updateQuestions.optionCField.setText("Animal");
        updateQuestions.optionDField.setText("Country");
        updateQuestions.correctAnswerBox.setSelectedItem("A");
        updateQuestions.levelBox.setSelectedItem("Beginner");

        // Simulate clicking the Update button
        updateQuestions.updateButton.doClick();

        // Assert that valid data is passed correctly to the mock method
        assertEquals(1, questionIDPassed);
        assertEquals("What is Java?", questionPassed);
        assertEquals("Programming Language", optionAPassed);
        assertEquals("Fruit", optionBPassed);
        assertEquals("Animal", optionCPassed);
        assertEquals("Country", optionDPassed);
        assertEquals("A", correctAnswerPassed);
        assertEquals("Beginner", levelPassed);
    }

    
}
