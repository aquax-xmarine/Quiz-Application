package assessment;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import javax.swing.*;

/**
 * Unit test for the {@link Register} class using JUnit 4.
 * This class tests the registration functionality of the application.
 * It verifies whether valid data is processed correctly when a user attempts to register.
 */
public class RegisterTest {

    private Register registerFrame;

    /**
     * Sets up the test environment before each test case.
     * Initializes the Register frame and ensures it's visible for interaction.
     * This method is executed before each test case.
     */
    @Before
    public void setUp() throws Exception {
        // Initialize the Register frame
        registerFrame = new Register();
        // Make sure the frame is visible for testing
        registerFrame.setVisible(true);
    }

    /**
     * Tests the registration process with valid input data.
     * It simulates the user filling out the registration form and clicking the submit button.
     */
    @Test
    public void testValidRegistration() {
        // Set valid input data
        registerFrame.txtID.setText("100");
        registerFrame.txtFirstName.setText("John");
        registerFrame.txtLastName.setText("Doe");
        registerFrame.txtAge.setText("25");
        registerFrame.comboLevel.setSelectedIndex(1);

        // Access btnSubmit directly (if accessible or with getter method)
        JButton btnSubmit = registerFrame.btnSubmit;  // Assuming it's public

        // Check if btnSubmit is not null
        assertNotNull("btnSubmit should not be null", btnSubmit);

        // Simulate button click
        btnSubmit.doClick();

        // Perform other checks here, as before
    }

}
