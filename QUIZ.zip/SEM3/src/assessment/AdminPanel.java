package assessment;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * The AdminPanel class represents the administrative interface that allows
 * the admin to perform various management actions, such as adding, updating, 
 * or deleting questions, as well as viewing reports and navigating back to 
 * the dashboard.
 */
public class AdminPanel extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    /**
     * Launches the AdminPanel frame.
     * 
     * @param args Command-line arguments (not used in this case).
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    AdminPanel frame = new AdminPanel();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Creates the frame for the Admin Panel.
     * Sets up the GUI components such as buttons for adding, updating, deleting 
     * questions, viewing reports, and navigating back or exiting the application.
     */
    public AdminPanel() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 332);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Admin Panel title
        JLabel frame = new JLabel("Admin Panel");
        frame.setFont(new Font("Viner Hand ITC", Font.PLAIN, 30));
        frame.setBounds(138, 25, 200, 52);
        contentPane.add(frame);

        // Button to add a question
        JButton btnAdd = new JButton("Add Question");
        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AddQuestions addQuestions = new AddQuestions();
                addQuestions.setVisible(true);
                dispose();
            }
        });
        btnAdd.setBounds(171, 107, 130, 21);
        contentPane.add(btnAdd);

        // Button to update a question
        JButton btnUpdate = new JButton("Update Question");
        btnUpdate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                UpdateQuestions updateQuestions = new UpdateQuestions();
                updateQuestions.setVisible(true);
                dispose();
            }
        });
        btnUpdate.setBounds(171, 138, 130, 21);
        contentPane.add(btnUpdate);

        // Button to delete a question
        JButton btnDelete = new JButton("Delete Question");
        btnDelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DeleteQuestions deleteQuestions = new DeleteQuestions();
                deleteQuestions.setVisible(true);
                dispose();
            }
        });
        btnDelete.setBounds(171, 169, 130, 21);
        contentPane.add(btnDelete);

        // Back button to navigate to the dashboard
        JButton btnBack = new JButton("Back");
        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Dashboard dashboard = new Dashboard();
                dashboard.setVisible(true);
                dispose();
            }
        });
        btnBack.setBounds(330, 227, 85, 21);
        contentPane.add(btnBack);

        // Exit button to close the application
        JButton btnExit = new JButton("Exit");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        btnExit.setBounds(330, 258, 85, 21);
        contentPane.add(btnExit);

        // Button to view statistical report
        JButton reportBtn = new JButton("View Report");
        reportBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                StatisticalReport statisticalReport = new StatisticalReport();
                statisticalReport.setVisible(true);
                dispose();
            }
        });
        reportBtn.setBounds(171, 200, 130, 21);
        contentPane.add(reportBtn);
    }
}
