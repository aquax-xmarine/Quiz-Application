package assessment;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.*;
import javax.swing.*;

/**
 * Unit test for the {@link AddQuestions} class using JUnit 5.
 * This class tests the functionality of adding questions to the quiz system.
 * It verifies whether the correct question details are passed to the database.
 */

class AddQuestionsTest {

    private AddQuestions addQuestions;
    private CompetitionDB mockDb;

    // A container for tracking the data being passed to addQuestion
    private String questionPassed;
    private String optionAPassed;
    private String optionBPassed;
    private String optionCPassed;
    private String optionDPassed;
    private String correctAnswerPassed;
    private String levelPassed;

    /**
     * Sets up the test environment before each test case.
     * Initializes a mock database and a test instance of {@link AddQuestions}.
     */
    @BeforeEach
    void setUp() {
        // Mock the database manager
        mockDb = new CompetitionDB() {
            @Override
            public boolean addQuestion(String question, String optionA, String optionB, String optionC, String optionD, String correctAnswer, String level) {
                // Track the values that are passed to the method
                questionPassed = question;
                optionAPassed = optionA;
                optionBPassed = optionB;
                optionCPassed = optionC;
                optionDPassed = optionD;
                correctAnswerPassed = correctAnswer;
                levelPassed = level;
                return !question.isEmpty() && !optionA.isEmpty() && !optionB.isEmpty() && !optionC.isEmpty() && !optionD.isEmpty();
            }
        };

        // Create the AddQuestions object and inject the mockDb
        addQuestions = new AddQuestions() {
            /**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
            public CompetitionDB getDbManager() {
                return mockDb;
            }
        };

        // Set up the necessary fields for testing
        addQuestions.questionField = new JTextField();
        addQuestions.optionAField = new JTextField();
        addQuestions.optionBField = new JTextField();
        addQuestions.optionCField = new JTextField();
        addQuestions.optionDField = new JTextField();
        addQuestions.correctAnswerBox = new JComboBox<>(new String[]{"A", "B", "C", "D"});
        addQuestions.levelBox = new JComboBox<>(new String[]{"Beginner", "Intermediate", "Advanced"});
        addQuestions.addButton = new JButton("Add");

        // Simulate the window creation
        addQuestions.setSize(430, 469);
        addQuestions.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        // Add an ActionListener to simulate the Add button's behavior
        addQuestions.addButton.addActionListener(e -> {
            mockDb.addQuestion(
                addQuestions.questionField.getText(),
                addQuestions.optionAField.getText(),
                addQuestions.optionBField.getText(),
                addQuestions.optionCField.getText(),
                addQuestions.optionDField.getText(),
                (String) addQuestions.correctAnswerBox.getSelectedItem(),
                (String) addQuestions.levelBox.getSelectedItem()
            );
        });
    }
    
    /**
     * Tests the addition of a valid question to ensure that correct data is passed to the database.
     * It simulates user input and verifies that the expected values match the stored values.
     */
    @Test
    void testAddQuestion_ValidData() {
        // Test valid data scenario
        addQuestions.questionField.setText("What is Java?");
        addQuestions.optionAField.setText("Programming Language");
        addQuestions.optionBField.setText("Fruit");
        addQuestions.optionCField.setText("Animal");
        addQuestions.optionDField.setText("Country");
        addQuestions.correctAnswerBox.setSelectedItem("A");
        addQuestions.levelBox.setSelectedItem("Beginner");

        // Simulate clicking the Add button
        addQuestions.addButton.doClick();
        System.out.println("Yes");

        // Assert that valid data is passed correctly
        assertEquals("What is Java?", questionPassed);
        assertEquals("Programming Language", optionAPassed);
        assertEquals("Fruit", optionBPassed);
        assertEquals("Animal", optionCPassed);
        assertEquals("Country", optionDPassed);
        assertEquals("A", correctAnswerPassed);
        assertEquals("Beginner", levelPassed);
    }
}
