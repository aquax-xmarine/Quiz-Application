package assessment;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * This class provides a GUI for adding questions to a competition database. 
 * It allows the user to input a question, options, select the correct answer 
 * and level, and then submit the question to the database.
 */
public class AddQuestions extends JFrame {
    private static final long serialVersionUID = 1L;
    
    // GUI components
    JTextField questionField;

	public JTextField optionAField;

	public JTextField optionBField;

	public JTextField optionCField;

	public JTextField optionDField;
    public JComboBox<String> correctAnswerBox, levelBox;
    public JButton addButton, cancelButton, backButton;

    // Database manager
    private CompetitionDB dbManager;

    /**
     * Constructs an AddQuestions frame, initializes the components,
     * and sets the layout and action listeners.
     */
    public AddQuestions() {
        dbManager = new CompetitionDB();

        // Frame setup
        setTitle("Add Question");
        setSize(430, 469);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        // Initialize labels and fields for question, options, and other fields
        initializeFields();

        // Buttons setup
        setupButtons();

        // Action listeners for buttons
        addButton.addActionListener(e -> addQuestion());
        cancelButton.addActionListener(e -> {
            dbManager.closeConnection(); // Close DB connection when exiting
            dispose();
        });

        setLocationRelativeTo(null);  // Center the frame
    }

    /**
     * Initializes the labels, text fields, combo boxes, and sets their positions on the frame.
     */
    private void initializeFields() {
        // Question Input
        JLabel label = new JLabel("Question:");
        label.setBounds(10, 10, 190, 41);
        getContentPane().add(label);
        questionField = new JTextField();
        questionField.setBounds(205, 10, 190, 41);
        getContentPane().add(questionField);

        // Options Input
        addOptionFields();

        // Correct Answer Dropdown
        JLabel label_5 = new JLabel("Correct Answer:");
        label_5.setBounds(10, 262, 190, 41);
        getContentPane().add(label_5);
        correctAnswerBox = new JComboBox<>(new String[]{"A", "B", "C", "D"});
        correctAnswerBox.setBounds(205, 262, 190, 41);
        getContentPane().add(correctAnswerBox);

        // Level Dropdown
        JLabel label_6 = new JLabel("Level:");
        label_6.setBounds(10, 313, 190, 41);
        getContentPane().add(label_6);
        levelBox = new JComboBox<>(new String[]{"Beginner", "Intermediate", "Advanced"});
        levelBox.setBounds(205, 313, 190, 41);
        getContentPane().add(levelBox);
    }

    /**
     * Adds fields for Option A, Option B, Option C, and Option D to the frame.
     */
    private void addOptionFields() {
        // Option A
        JLabel label_1 = new JLabel("Option A:");
        label_1.setBounds(10, 58, 190, 41);
        getContentPane().add(label_1);
        optionAField = new JTextField();
        optionAField.setBounds(205, 58, 190, 41);
        getContentPane().add(optionAField);

        // Option B
        JLabel label_2 = new JLabel("Option B:");
        label_2.setBounds(10, 109, 190, 41);
        getContentPane().add(label_2);
        optionBField = new JTextField();
        optionBField.setBounds(205, 109, 190, 41);
        getContentPane().add(optionBField);

        // Option C
        JLabel label_3 = new JLabel("Option C:");
        label_3.setBounds(10, 160, 190, 41);
        getContentPane().add(label_3);
        optionCField = new JTextField();
        optionCField.setBounds(205, 160, 190, 41);
        getContentPane().add(optionCField);

        // Option D
        JLabel label_4 = new JLabel("Option D:");
        label_4.setBounds(10, 211, 190, 41);
        getContentPane().add(label_4);
        optionDField = new JTextField();
        optionDField.setBounds(205, 211, 190, 41);
        getContentPane().add(optionDField);
    }

    /**
     * Sets up the action buttons: Add, Cancel, and Back.
     */
    private void setupButtons() {
        // Add Button
        addButton = new JButton("Add");
        addButton.setBounds(20, 381, 107, 41);
        getContentPane().add(addButton);

        // Cancel Button
        cancelButton = new JButton("Exit");
        cancelButton.setBounds(170, 381, 102, 41);
        getContentPane().add(cancelButton);

        // Back Button
        backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AdminPanel adminPanel = new AdminPanel();
                adminPanel.setVisible(true);
                dispose();
            }
        });
        backButton.setBounds(293, 381, 92, 41);
        getContentPane().add(backButton);
    }

    /**
     * Validates the input fields and adds the question to the competition database.
     * Displays appropriate success or error messages.
     */
    private void addQuestion() {
        String question = questionField.getText();
        String optionA = optionAField.getText();
        String optionB = optionBField.getText();
        String optionC = optionCField.getText();
        String optionD = optionDField.getText();
        String correctAnswer = correctAnswerBox.getSelectedItem().toString();
        String level = levelBox.getSelectedItem().toString();

        // Validate input fields
        if (question.isEmpty() || optionA.isEmpty() || optionB.isEmpty() || optionC.isEmpty() || optionD.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Add question to database
        boolean success = dbManager.addQuestion(question, optionA, optionB, optionC, optionD, correctAnswer, level);
        if (success) {
            JOptionPane.showMessageDialog(this, "Question added successfully!");
            clearFields();
        } else {
            JOptionPane.showMessageDialog(this, "Error adding question!", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Clears all the input fields after a question is successfully added.
     */
    private void clearFields() {
        questionField.setText("");
        optionAField.setText("");
        optionBField.setText("");
        optionCField.setText("");
        optionDField.setText("");
        correctAnswerBox.setSelectedIndex(0);
        levelBox.setSelectedIndex(0);
    }

    /**
     * The main method to start the application.
     * @param args command-line arguments (not used)
     */

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AddQuestions().setVisible(true));
    }

	public CompetitionDB getDbManager() {
		// TODO Auto-generated method stub
		return null;
	}
}
