package assessment;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * The LeaderboardUser class represents the user interface for viewing the competition leaderboard.
 * It allows users to filter the leaderboard by competition level (Beginner, Intermediate, Advanced) and displays
 * the leaderboard in a table format. Users can also navigate back to the sign-in page or exit the application.
 */
public class LeaderboardUser extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JComboBox<String> levelFilter;
    private JTable leaderboardTable;
    private CompetitionDB dbManager; // Database manager for fetching leaderboard data
    private JButton exitButton;
    private JButton backButton;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    LeaderboardUser frame = new LeaderboardUser();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Constructs the LeaderboardUser frame.
     * Initializes the database manager, UI components (level filter dropdown, leaderboard table, buttons),
     * and sets up event listeners for actions such as filtering the leaderboard and navigating between pages.
     */
    public LeaderboardUser() {
        dbManager = new CompetitionDB(); // Initialize the database manager

        setTitle("Leaderboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 500, 555); // Increased height to accommodate buttons

        contentPane = new JPanel();
        setContentPane(contentPane);

        // Dropdown to filter leaderboard by level
        String[] levels = {"All", "Beginner", "Intermediate", "Advanced"};
        contentPane.setLayout(null);
        levelFilter = new JComboBox<>(levels);
        levelFilter.setBounds(0, 0, 486, 19);
        contentPane.add(levelFilter);

        // Table to display leaderboard
        leaderboardTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(leaderboardTable);
        scrollPane.setBounds(0, 19, 486, 426);
        contentPane.add(scrollPane);

        // Buttons Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBounds(0, 445, 486, 73);
        contentPane.add(buttonPanel);

        // Exit Button
        exitButton = new JButton("Exit");
        exitButton.setBounds(401, 42, 80, 21);
        exitButton.addActionListener(e -> System.exit(0)); // Exit the application
        buttonPanel.setLayout(null);
        buttonPanel.add(exitButton);

        // Back Button
        backButton = new JButton("Back");
        backButton.setBounds(401, 11, 80, 21);
        backButton.addActionListener(e -> {
        	SignIn signIn = new SignIn();
			signIn.setVisible(true);
			dispose();
            dispose();
        });
        buttonPanel.add(backButton);

        // Load leaderboard when a level is selected
        levelFilter.addActionListener(e -> loadLeaderboard());

        loadLeaderboard(); // Initial load of the leaderboard
    }

    /**
     * Inner class representing top performers for each competition level.
     * Stores the top performer for each level: Beginner, Intermediate, and Advanced.
     */
    public static class TopPerformers {
        public Competitor beginner;
        public Competitor intermediate;
        public Competitor advanced;
    }

    /**
     * Gets the top performers for each competition level based on the current leaderboard.
     * 
     * @param levelFilter The competition level filter (e.g., "Beginner", "Intermediate", "Advanced").
     * @return A TopPerformers object containing the top performers for each level.
     */
    public TopPerformers getTopPerformers(String levelFilter) {
        List<Competitor> leaderboard = dbManager.getLeaderboard(levelFilter);
        
        Competitor topBeginner = null;
        Competitor topIntermediate = null;
        Competitor topAdvanced = null;

        // Find top performers for each level
        for (Competitor competitor : leaderboard) {
            switch (competitor.getCompetitionLevel()) {
                case "Beginner":
                    if (topBeginner == null || competitor.getOverallScore() > topBeginner.getOverallScore()) {
                        topBeginner = competitor;
                    }
                    break;
                case "Intermediate":
                    if (topIntermediate == null || competitor.getOverallScore() > topIntermediate.getOverallScore()) {
                        topIntermediate = competitor;
                    }
                    break;
                case "Advanced":
                    if (topAdvanced == null || competitor.getOverallScore() > topAdvanced.getOverallScore()) {
                        topAdvanced = competitor;
                    }
                    break;
            }
        }

        TopPerformers topPerformers = new TopPerformers();
        topPerformers.beginner = topBeginner;
        topPerformers.intermediate = topIntermediate;
        topPerformers.advanced = topAdvanced;
        
        return topPerformers;
    }

    /**
     * Loads and updates the leaderboard based on the selected level filter.
     * If the leaderboard is empty, a message will be shown. Otherwise, the leaderboard is populated
     * in the table with competitor details.
     */
    private void loadLeaderboard() {
        String selectedLevel = (String) levelFilter.getSelectedItem();
        List<Competitor> leaderboard = dbManager.getLeaderboard(selectedLevel);

        // Check if leaderboard is empty
        if (leaderboard.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No competitors found.");
            return;
        }

        // Create table model with column names
        String[] columnNames = {"Competitor ID", "Name", "Level", "Age", "Overall Score"};
        Object[][] data = new Object[leaderboard.size()][5];

        // Populate the table data
        for (int i = 0; i < leaderboard.size(); i++) {
            Competitor competitor = leaderboard.get(i);
            data[i][0] = competitor.getCompetitorID();
            data[i][1] = competitor.getCompetitorName().getFullName();
            data[i][2] = competitor.getCompetitionLevel();
            data[i][3] = competitor.getAge();
            data[i][4] = String.format("%.1f", competitor.getOverallScore());  // Format score to 1 decimal place
        }

        // Set table model with data
        leaderboardTable.setModel(new javax.swing.table.DefaultTableModel(data, columnNames));
    }
}
