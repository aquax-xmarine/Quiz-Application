package assessment;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * The AdminCredentials class represents a login interface where administrators
 * can enter their credentials to access the Admin Panel of the application.
 * It provides functionality to validate the entered username and password.
 */
public class AdminCredentials extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtUsername;
    private JTextField txtPassword;

    // Predefined username and password
    private final String correctUsername = "admin";
    private final String correctPassword = "password123";

    /**
     * Launches the AdminCredentials frame.
     * 
     * @param args Command-line arguments (not used in this case).
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    AdminCredentials frame = new AdminCredentials();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Creates the frame for AdminCredentials.
     * Sets up the GUI components such as labels, text fields, and buttons.
     */
    public AdminCredentials() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 336);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Sign In title
        JLabel frame = new JLabel("Sign In");
        frame.setFont(new Font("Viner Hand ITC", Font.PLAIN, 30));
        frame.setBounds(176, 29, 120, 49);
        contentPane.add(frame);

        // Username label
        JLabel lblUsername = new JLabel("Username");
        lblUsername.setBounds(124, 113, 71, 13);
        contentPane.add(lblUsername);

        // Password label
        JLabel lblPassword = new JLabel("Password");
        lblPassword.setBounds(124, 164, 71, 13);
        contentPane.add(lblPassword);

        // Username input field
        txtUsername = new JTextField();
        txtUsername.setBounds(221, 110, 96, 19);
        contentPane.add(txtUsername);
        txtUsername.setColumns(10);

        // Password input field
        txtPassword = new JTextField();
        txtPassword.setBounds(221, 161, 96, 19);
        contentPane.add(txtPassword);
        txtPassword.setColumns(10);

        // Submit button for login
        JButton btnSubmit = new JButton("Submit");
        btnSubmit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Get entered username and password
                String enteredUsername = txtUsername.getText();
                String enteredPassword = txtPassword.getText();

                // Check if the entered username and password match the correct ones
                if (enteredUsername.equals(correctUsername) && enteredPassword.equals(correctPassword)) {
                    // Login successful
                    JOptionPane.showMessageDialog(null, "Login successful!");
                    AdminPanel adminPanel = new AdminPanel();
                    adminPanel.setVisible(true);
                    dispose();
                } else {
                    // Login failed
                    JOptionPane.showMessageDialog(null, "Incorrect username or password.", "Login Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        btnSubmit.setBounds(180, 199, 85, 21);
        contentPane.add(btnSubmit);

        // Exit button to close the application
        JButton btnExit = new JButton("Exit");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        btnExit.setBounds(341, 268, 85, 21);
        contentPane.add(btnExit);

        // Back button to navigate to the dashboard
        JButton btnBack = new JButton("Back");
        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Dashboard dashboard = new Dashboard();
                dashboard.setVisible(true);
                dispose();
            }
        });
        btnBack.setBounds(341, 244, 85, 21);
        contentPane.add(btnBack);
    }
}
