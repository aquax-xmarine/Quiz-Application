package assessment;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Collections;

/**
 * The {@code QuizGUI} class represents the graphical user interface (GUI) for a quiz.
 * It allows the user to answer multiple-choice questions and tracks the score.
 */
public class QuizGUI extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel lblQuestion;
    private JRadioButton optionA, optionB, optionC, optionD;
    private ButtonGroup optionsGroup;
    private JButton btnNext;
    private List<QuestionText> questions;
    private int currentQuestionIndex = 0;
    private int score = 0;
    private CompetitionDB dbManager;
    private int competitorID; // Store competitor ID to use when updating the score

    /**
     * Constructs a {@code QuizGUI} object to display the quiz for a given level and competitor.
     *
     * @param Level       The difficulty level of the quiz.
     * @param competitorID The ID of the competitor taking the quiz.
     */
    public QuizGUI(String Level, int competitorID) {
        this.setCompetitorID(competitorID);  // Set competitor ID
        setTitle("Quiz");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 500, 300);
        contentPane = new JPanel();
        contentPane.setLayout(new BorderLayout());
        setContentPane(contentPane);

        lblQuestion = new JLabel("", SwingConstants.CENTER);
        contentPane.add(lblQuestion, BorderLayout.NORTH);

        JPanel optionsPanel = new JPanel();
        optionsPanel.setLayout(new GridLayout(4, 1));
        optionA = new JRadioButton();
        optionB = new JRadioButton();
        optionC = new JRadioButton();
        optionD = new JRadioButton();

        optionsGroup = new ButtonGroup();
        optionsGroup.add(optionA);
        optionsGroup.add(optionB);
        optionsGroup.add(optionC);
        optionsGroup.add(optionD);

        optionsPanel.add(optionA);
        optionsPanel.add(optionB);
        optionsPanel.add(optionC);
        optionsPanel.add(optionD);
        contentPane.add(optionsPanel, BorderLayout.CENTER);

        btnNext = new JButton("Next");
        contentPane.add(btnNext, BorderLayout.SOUTH);

        // Fetch questions using DatabaseHelper
        dbManager = new CompetitionDB();
        questions = dbManager.fetchQuestions(Level);

        // Ensure only 5 questions are used, if there are more than 5
        if (questions.size() > 5) {
            questions = questions.subList(0, 5);
        }

        Collections.shuffle(questions);
        displayQuestion();

        btnNext.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkAnswer();
                currentQuestionIndex++;
                if (currentQuestionIndex < 5) {
                    displayQuestion();
                } else {
                    JOptionPane.showMessageDialog(null, "Quiz Over! \nDifficulty Level: " + Level + "\nNumber of correct answer: " + score + "\nScore: " + score + "/5");
                    // Update score in the database for the competitor
                    dbManager.updateScore(competitorID, score); // Call to updateScore method
                    dispose();
                }
            }
        });
    }

    /**
     * Displays the current question and its options.
     */
    private void displayQuestion() {
        QuestionText q = questions.get(currentQuestionIndex);  // Use QuestionText
        lblQuestion.setText(q.getQuestionText());  // Use correct getter
        optionA.setText(q.getOptionA());
        optionB.setText(q.getOptionB());
        optionC.setText(q.getOptionC());
        optionD.setText(q.getOptionD());
        optionsGroup.clearSelection();
    }

    /**
     * Checks the selected answer against the correct answer and updates the score.
     */
    private void checkAnswer() {
        QuestionText q = questions.get(currentQuestionIndex);  // Use QuestionText
        String selectedAnswer = null;
        
        if (optionA.isSelected()) selectedAnswer = optionA.getText();
        else if (optionB.isSelected()) selectedAnswer = optionB.getText();
        else if (optionC.isSelected()) selectedAnswer = optionC.getText();
        else if (optionD.isSelected()) selectedAnswer = optionD.getText();

        // Ensure that the selected answer and correct answer are not null
        if (selectedAnswer != null && q.getCorrectAnswer() != null) {
            // Convert the selected answer text to the corresponding letter (A, B, C, D)
            String selectedAnswerLetter = null;
            
            if (selectedAnswer.equals(optionA.getText())) selectedAnswerLetter = "A";
            else if (selectedAnswer.equals(optionB.getText())) selectedAnswerLetter = "B";
            else if (selectedAnswer.equals(optionC.getText())) selectedAnswerLetter = "C";
            else if (selectedAnswer.equals(optionD.getText())) selectedAnswerLetter = "D";
            
            boolean isCorrect = selectedAnswerLetter != null && selectedAnswerLetter.equalsIgnoreCase(q.getCorrectAnswer().trim());

            // Show message dialog for each answer
            if (isCorrect) {
                score++;
                JOptionPane.showMessageDialog(this, "Correct! ✅", "Result", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Incorrect ❌", "Result", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Main method for testing purposes.
     * 
     * @param args Command-line arguments.
     */
    public static void main(String[] args) {
        // Example: Create a new quiz for a competitor with ID 123
//        new QuizGUI("Beginner", 123).setVisible(true);
    }

    /**
     * Gets the competitor ID.
     *
     * @return The competitor ID.
     */
    public int getCompetitorID() {
        return competitorID;
    }

    /**
     * Sets the competitor ID.
     *
     * @param competitorID The competitor ID to set.
     */
    public void setCompetitorID(int competitorID) {
        this.competitorID = competitorID;
    }
}
