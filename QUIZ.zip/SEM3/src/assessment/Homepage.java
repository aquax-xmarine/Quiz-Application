package assessment;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * The Homepage class represents the main window for the "Player Panel" in the application.
 * It provides buttons for players to sign in, register, navigate back to the dashboard, or exit the application.
 * 
 * <p>The frame includes a title label and four buttons, each with specific functionality:
 * 1. "Sign in" - Allows the player to sign in.
 * 2. "Register" - Allows the player to register.
 * 3. "Back" - Navigates back to the dashboard.
 * 4. "Exit" - Exits the application.</p>
 */
public class Homepage extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 * This method initializes and displays the Homepage window.
	 * 
	 * @param args Command-line arguments (not used).
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Homepage frame = new Homepage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Constructs the Homepage window.
	 * It initializes the frame, sets its layout, and adds components such as labels and buttons.
	 * The buttons are associated with actions like signing in, registering, going back to the dashboard,
	 * and exiting the application.
	 */
	public Homepage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 493, 340);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		// Label for the title
		JLabel frame = new JLabel("Player Panel");
		frame.setFont(new Font("Viner Hand ITC", Font.PLAIN, 30));
		frame.setBounds(142, 46, 199, 53);
		contentPane.add(frame);

		// "Sign in" button with action to navigate to SignIn screen
		JButton btnSignIn = new JButton("Sign in");
		btnSignIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SignIn signin = new SignIn();
				signin.setVisible(true);
				dispose();
			}
		});
		btnSignIn.setBounds(193, 125, 85, 21);
		contentPane.add(btnSignIn);

		// "Register" button with action to navigate to Register screen
		JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Register register = new Register();
				register.setVisible(true);
				dispose();
			}
		});
		btnRegister.setBounds(193, 156, 85, 21);
		contentPane.add(btnRegister);

		// "Back" button with action to navigate to Dashboard
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Dashboard dashboard = new Dashboard();
				dashboard.setVisible(true);
				dispose();
			}
		});
		btnBack.setBounds(383, 247, 86, 21);
		contentPane.add(btnBack);

		// "Exit" button with action to exit the application
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setBounds(384, 272, 85, 21);
		contentPane.add(btnExit);
	}
}
